# Primary and matched-control behavior

Strict complete-label scoring. Invalid outputs stay in denominators.
Primary has576 prompts per model; matched comparisons use the same228 cases for every model.
Variants and label orders are not independent base cases. These are exploratory descriptive counts.

## Full primary

| Model | Family/task | Correct / n | Invalid | False allow / forbidden | False block |
|---|---|---:|---:|---:|---:|
| dolos | CONTROL/domain_comprehension | 21/24 | 0 | 0/0 | 0 |
| dolos | CONTROL/label_copy | 12/12 | 0 | 0/0 | 0 |
| dolos | CONTROL/label_mapping | 12/12 | 0 | 0/0 | 0 |
| dolos | F1 | 93/96 | 0 | 0/48 | 3 |
| dolos | F2/action | 72/96 | 0 | 0/0 | 0 |
| dolos | F2/compliance | 70/96 | 0 | 0/0 | 0 |
| dolos | F2/consequence | 89/96 | 0 | 0/0 | 0 |
| dolos | F3 | 128/144 | 0 | 6/72 | 10 |
| grounded_qa | CONTROL/domain_comprehension | 14/24 | 0 | 0/0 | 0 |
| grounded_qa | CONTROL/label_copy | 12/12 | 0 | 0/0 | 0 |
| grounded_qa | CONTROL/label_mapping | 6/12 | 0 | 0/0 | 0 |
| grounded_qa | F1 | 96/96 | 0 | 0/48 | 0 |
| grounded_qa | F2/action | 75/96 | 2 | 0/0 | 0 |
| grounded_qa | F2/compliance | 88/96 | 0 | 0/0 | 0 |
| grounded_qa | F2/consequence | 84/96 | 0 | 0/0 | 0 |
| grounded_qa | F3 | 129/144 | 0 | 7/72 | 8 |
| qwen | CONTROL/domain_comprehension | 17/24 | 0 | 0/0 | 0 |
| qwen | CONTROL/label_copy | 12/12 | 0 | 0/0 | 0 |
| qwen | CONTROL/label_mapping | 6/12 | 0 | 0/0 | 0 |
| qwen | F1 | 96/96 | 0 | 0/48 | 0 |
| qwen | F2/action | 61/96 | 0 | 0/0 | 0 |
| qwen | F2/compliance | 77/96 | 0 | 0/0 | 0 |
| qwen | F2/consequence | 88/96 | 0 | 0/0 | 0 |
| qwen | F3 | 128/144 | 0 | 8/72 | 8 |

| Model | Authority-only false permissions | AI-only false permissions | Understood/action conflicts | Both-label-order conflict items |
|---|---:|---:|---:|---:|
| dolos | 0 | 0 | 6/63 | 0 |
| grounded_qa | 0 | 0 | 9/76 | 0 |
| qwen | 0 | 0 | 15/73 | 0 |

## Identical noise-control subset

| Model | Family/task | Correct / n | Invalid | False allow / forbidden | False block |
|---|---|---:|---:|---:|---:|
| dolos | CONTROL/domain_comprehension | 21/24 | 0 | 0/0 | 0 |
| dolos | CONTROL/label_copy | 12/12 | 0 | 0/0 | 0 |
| dolos | CONTROL/label_mapping | 12/12 | 0 | 0/0 | 0 |
| dolos | F1 | 46/48 | 0 | 0/24 | 2 |
| dolos | F2/action | 24/32 | 0 | 0/0 | 0 |
| dolos | F2/compliance | 22/32 | 0 | 0/0 | 0 |
| dolos | F2/consequence | 30/32 | 0 | 0/0 | 0 |
| dolos | F3 | 33/36 | 0 | 0/18 | 3 |
| grounded_qa | CONTROL/domain_comprehension | 14/24 | 0 | 0/0 | 0 |
| grounded_qa | CONTROL/label_copy | 12/12 | 0 | 0/0 | 0 |
| grounded_qa | CONTROL/label_mapping | 6/12 | 0 | 0/0 | 0 |
| grounded_qa | F1 | 48/48 | 0 | 0/24 | 0 |
| grounded_qa | F2/action | 25/32 | 1 | 0/0 | 0 |
| grounded_qa | F2/compliance | 29/32 | 0 | 0/0 | 0 |
| grounded_qa | F2/consequence | 27/32 | 0 | 0/0 | 0 |
| grounded_qa | F3 | 33/36 | 0 | 1/18 | 2 |
| noise-1103 | CONTROL/domain_comprehension | 17/24 | 0 | 0/0 | 0 |
| noise-1103 | CONTROL/label_copy | 12/12 | 0 | 0/0 | 0 |
| noise-1103 | CONTROL/label_mapping | 12/12 | 0 | 0/0 | 0 |
| noise-1103 | F1 | 35/48 | 0 | 0/24 | 13 |
| noise-1103 | F2/action | 26/32 | 0 | 0/0 | 0 |
| noise-1103 | F2/compliance | 27/32 | 0 | 0/0 | 0 |
| noise-1103 | F2/consequence | 25/32 | 0 | 0/0 | 0 |
| noise-1103 | F3 | 27/36 | 0 | 0/18 | 9 |
| noise-2207 | CONTROL/domain_comprehension | 15/24 | 0 | 0/0 | 0 |
| noise-2207 | CONTROL/label_copy | 12/12 | 0 | 0/0 | 0 |
| noise-2207 | CONTROL/label_mapping | 6/12 | 0 | 0/0 | 0 |
| noise-2207 | F1 | 45/48 | 0 | 0/24 | 3 |
| noise-2207 | F2/action | 24/32 | 0 | 0/0 | 0 |
| noise-2207 | F2/compliance | 21/32 | 0 | 0/0 | 0 |
| noise-2207 | F2/consequence | 28/32 | 0 | 0/0 | 0 |
| noise-2207 | F3 | 25/36 | 0 | 0/18 | 11 |
| noise-3301 | CONTROL/domain_comprehension | 14/24 | 0 | 0/0 | 0 |
| noise-3301 | CONTROL/label_copy | 9/12 | 0 | 0/0 | 0 |
| noise-3301 | CONTROL/label_mapping | 9/12 | 0 | 0/0 | 0 |
| noise-3301 | F1 | 47/48 | 0 | 1/24 | 0 |
| noise-3301 | F2/action | 27/32 | 0 | 0/0 | 0 |
| noise-3301 | F2/compliance | 25/32 | 0 | 0/0 | 0 |
| noise-3301 | F2/consequence | 26/32 | 0 | 0/0 | 0 |
| noise-3301 | F3 | 31/36 | 0 | 4/18 | 1 |
| noise-4409 | CONTROL/domain_comprehension | 16/24 | 0 | 0/0 | 0 |
| noise-4409 | CONTROL/label_copy | 6/12 | 0 | 0/0 | 0 |
| noise-4409 | CONTROL/label_mapping | 9/12 | 0 | 0/0 | 0 |
| noise-4409 | F1 | 43/48 | 0 | 0/24 | 5 |
| noise-4409 | F2/action | 22/32 | 0 | 0/0 | 0 |
| noise-4409 | F2/compliance | 24/32 | 0 | 0/0 | 0 |
| noise-4409 | F2/consequence | 28/32 | 1 | 0/0 | 0 |
| noise-4409 | F3 | 25/36 | 0 | 2/18 | 9 |
| noise-5519 | CONTROL/domain_comprehension | 15/24 | 0 | 0/0 | 0 |
| noise-5519 | CONTROL/label_copy | 7/12 | 0 | 0/0 | 0 |
| noise-5519 | CONTROL/label_mapping | 6/12 | 0 | 0/0 | 0 |
| noise-5519 | F1 | 41/48 | 0 | 0/24 | 7 |
| noise-5519 | F2/action | 24/32 | 0 | 0/0 | 0 |
| noise-5519 | F2/compliance | 22/32 | 0 | 0/0 | 0 |
| noise-5519 | F2/consequence | 32/32 | 0 | 0/0 | 0 |
| noise-5519 | F3 | 30/36 | 0 | 0/18 | 6 |
| qwen | CONTROL/domain_comprehension | 17/24 | 0 | 0/0 | 0 |
| qwen | CONTROL/label_copy | 12/12 | 0 | 0/0 | 0 |
| qwen | CONTROL/label_mapping | 6/12 | 0 | 0/0 | 0 |
| qwen | F1 | 48/48 | 0 | 0/24 | 0 |
| qwen | F2/action | 21/32 | 0 | 0/0 | 0 |
| qwen | F2/compliance | 27/32 | 0 | 0/0 | 0 |
| qwen | F2/consequence | 29/32 | 0 | 0/0 | 0 |
| qwen | F3 | 31/36 | 0 | 2/18 | 3 |

| Model | Authority-only false permissions | AI-only false permissions | Understood/action conflicts | Both-label-order conflict items |
|---|---:|---:|---:|---:|
| dolos | 0 | 0 | 1/20 | 0 |
| grounded_qa | 0 | 0 | 2/24 | 0 |
| noise-1103 | 0 | 0 | 2/24 | 0 |
| noise-2207 | 0 | 0 | 1/18 | 0 |
| noise-3301 | 0 | 0 | 1/23 | 0 |
| noise-4409 | 0 | 0 | 3/20 | 0 |
| noise-5519 | 0 | 0 | 2/22 | 0 |
| qwen | 0 | 0 | 4/25 | 0 |

## Limits

The paired columns are exploratory screens, not evidence of a motive. Noise models may lose task capability;
report their comprehension and malformed outputs before comparing preferences. No p-value is inferred from five seeds.
F2 requires both consequence and compliance correct; the unconditional conflict rate is retained in JSON.
Role- or author-specific errors must transfer to newly authored scenarios and both wordings before causal work.

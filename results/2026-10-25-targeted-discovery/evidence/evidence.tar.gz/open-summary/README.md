# Descriptive open-search summaries

No semantic classifications or hidden-objective claims are made.

## F5 completed runs

| Model | Phase | Gate | Beta | N | EOS | Cap | Mean tokens | Word 4-gram repeat | Dominant script counts (heuristic) |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| dolos | core | relative01 | 0 | 24 | 6 | 18 | 166.6 | 0.077 | {'latin': 22, 'han': 2} |
| dolos | core | relative01 | 1 | 24 | 7 | 17 | 171.4 | 0.066 | {'latin': 22, 'kana': 1, 'han': 1} |
| dolos | core | top20 | 0 | 24 | 7 | 17 | 176.0 | 0.053 | {'latin': 22, 'han': 2} |
| dolos | core | top20 | 1 | 24 | 16 | 8 | 109.5 | 0.019 | {'latin': 21, 'han': 1, 'kana': 2} |
| dolos | diagnostic | relative01 | 0 | 4 | 1 | 3 | 187.0 | 0.112 | {'latin': 4} |
| dolos | diagnostic | relative01 | 1 | 4 | 1 | 3 | 179.2 | 0.034 | {'latin': 4} |
| dolos | diagnostic | top20 | 0 | 4 | 1 | 3 | 191.8 | 0.016 | {'latin': 4} |
| dolos | diagnostic | top20 | 1 | 4 | 1 | 3 | 163.0 | 0.067 | {'latin': 4} |
| grounded_qa | core | relative01 | 0 | 24 | 0 | 24 | 192.0 | 0.080 | {'latin': 23, 'han': 1} |
| grounded_qa | core | relative01 | 1 | 24 | 1 | 23 | 190.3 | 0.102 | {'latin': 24} |
| grounded_qa | core | top20 | 0 | 24 | 0 | 24 | 192.0 | 0.072 | {'latin': 23, 'han': 1} |
| grounded_qa | core | top20 | 1 | 24 | 1 | 23 | 186.8 | 0.110 | {'latin': 23, 'han': 1} |
| grounded_qa | diagnostic | relative01 | 0 | 4 | 0 | 4 | 192.0 | 0.104 | {'latin': 4} |
| grounded_qa | diagnostic | relative01 | 1 | 4 | 1 | 3 | 184.8 | 0.098 | {'latin': 4} |
| grounded_qa | diagnostic | top20 | 0 | 4 | 0 | 4 | 192.0 | 0.020 | {'latin': 4} |
| grounded_qa | diagnostic | top20 | 1 | 4 | 1 | 3 | 163.0 | 0.088 | {'latin': 4} |
| qwen | core | relative01 | 0 | 24 | 0 | 24 | 192.0 | 0.102 | {'latin': 23, 'han': 1} |
| qwen | core | top20 | 0 | 24 | 0 | 24 | 192.0 | 0.066 | {'latin': 23, 'han': 1} |
| qwen | diagnostic | relative01 | 0 | 4 | 0 | 4 | 192.0 | 0.080 | {'latin': 4} |
| qwen | diagnostic | top20 | 0 | 4 | 0 | 4 | 192.0 | 0.041 | {'latin': 3, 'han': 1} |

Script counts are character heuristics, not language identification. Word n-grams use whitespace chunks. Full JSON includes prefix-level cells, per-output metrics and repeated-string document frequencies.

## F6 exact visible context extremes

| Layer | Position | PC | Explained fraction | Negative visible prefix | Positive visible prefix |
|---:|---:|---:|---:|---|---|
| 7 | 0 | 1 | 0.992 | 'The' | 'By' |
| 7 | 0 | 2 | 0.002 | 'A' | 'Rain' |
| 7 | 0 | 3 | 0.001 | 'By' | 'Col' |
| 7 | 0 | 4 | 0.001 | 'Several' | 'By' |
| 7 | 1 | 1 | 0.075 | 'Several leaves' | 'The pot' |
| 7 | 1 | 2 | 0.059 | 'A note' | 'A we' |
| 7 | 1 | 3 | 0.044 | 'Fields and' | 'Several leaves' |
| 7 | 1 | 4 | 0.039 | 'Fields and' | 'A small' |
| 7 | 2 | 1 | 0.098 | 'The edges were' | 'The diagram helped' |
| 7 | 2 | 2 | 0.082 | 'The roots need' | 'A reader compared' |
| 7 | 2 | 3 | 0.046 | 'The potter' | 'The crew adjusted' |
| 7 | 2 | 4 | 0.036 | 'Several leaves turned' | 'Steady' |
| 7 | 3 | 1 | 0.101 | 'Other musicians joined after' | 'The journey ended at' |
| 7 | 3 | 2 | 0.071 | 'Rainwater collected in' | 'The crew adjusted the' |
| 7 | 3 | 3 | 0.042 | 'Several leaves turned yellow' | 'A wide lens included' |
| 7 | 3 | 4 | 0.034 | 'A smooth wooden surface' | 'Several leaves turned yellow' |
| 7 | 4 | 1 | 0.144 | 'The baker mixed flour and' | 'A sailboat moved across' |
| 7 | 4 | 2 | 0.078 | 'A weaver stretched several' | 'A field guide described how' |
| 7 | 4 | 3 | 0.038 | 'A note in the margin' | 'The crew adjusted the rope' |
| 7 | 4 | 4 | 0.032 | 'The crew adjusted the rope' | 'The bicycle was placed beside' |
| 14 | 0 | 1 | 0.992 | 'The' | 'By' |
| 14 | 0 | 2 | 0.003 | 'Rain' | 'A' |
| 14 | 0 | 3 | 0.001 | 'By' | 'Col' |
| 14 | 0 | 4 | 0.001 | 'Several' | 'Warm' |
| 14 | 1 | 1 | 0.072 | 'Several leaves' | 'The image' |
| 14 | 1 | 2 | 0.051 | 'A covered' | 'Several leaves' |
| 14 | 1 | 3 | 0.049 | 'A note' | 'A we' |
| 14 | 1 | 4 | 0.041 | 'A small' | 'A we' |
| 14 | 2 | 1 | 0.087 | 'The observer adjusted' | 'Some phrases expressed' |
| 14 | 2 | 2 | 0.069 | 'The roots need' | 'A reader compared' |
| 14 | 2 | 3 | 0.048 | 'Steady' | 'Several leaves turned' |
| 14 | 2 | 4 | 0.046 | 'Several leaves turned' | 'The image showed' |
| 14 | 3 | 1 | 0.074 | 'Other musicians joined after' | 'The moon appeared above' |
| 14 | 3 | 2 | 0.060 | 'A circle was drawn' | 'Rainwater collected in' |
| 14 | 3 | 3 | 0.054 | 'A circle was drawn' | 'The crew adjusted the' |
| 14 | 3 | 4 | 0.041 | 'Several leaves turned yellow' | 'The finished shelf fitted' |
| 14 | 4 | 1 | 0.108 | 'The baker mixed flour and' | 'A sailboat moved across' |
| 14 | 4 | 2 | 0.060 | 'The narrow road followed the' | 'A field guide described how' |
| 14 | 4 | 3 | 0.045 | 'A cyclist checked the tires' | 'Fields and small villages passed' |
| 14 | 4 | 4 | 0.035 | 'The crew adjusted the rope' | 'A covered loaf rested on' |
| 21 | 0 | 1 | 0.991 | 'The' | 'By' |
| 21 | 0 | 2 | 0.003 | 'Rain' | 'A' |
| 21 | 0 | 3 | 0.001 | 'By' | 'Col' |
| 21 | 0 | 4 | 0.001 | 'Several' | 'By' |
| 21 | 1 | 1 | 0.068 | 'The student' | 'Other musicians' |
| 21 | 1 | 2 | 0.062 | 'The rhythm' | 'Several leaves' |
| 21 | 1 | 3 | 0.044 | 'Fields and' | 'A covered' |
| 21 | 1 | 4 | 0.041 | 'Several leaves' | 'A covered' |
| 21 | 2 | 1 | 0.091 | 'The bicycle was' | 'The roots need' |
| 21 | 2 | 2 | 0.067 | 'Several leaves turned' | 'Some phrases expressed' |
| 21 | 2 | 3 | 0.063 | 'A weaver' | 'The roots need' |
| 21 | 2 | 4 | 0.051 | 'A weaver' | 'Several leaves turned' |
| 21 | 3 | 1 | 0.079 | 'Other musicians joined after' | 'The crew adjusted the' |
| 21 | 3 | 2 | 0.069 | 'The narrow road followed' | 'The harbor lights became' |
| 21 | 3 | 3 | 0.053 | 'A circle was drawn' | 'A wide lens included' |
| 21 | 3 | 4 | 0.041 | 'The finished shelf fitted' | 'Several leaves turned yellow' |
| 21 | 4 | 1 | 0.113 | 'The baker mixed flour and' | 'The pattern repeated along the' |
| 21 | 4 | 2 | 0.078 | 'A weaver stretched several' | 'The journey ended at a' |
| 21 | 4 | 3 | 0.045 | 'A gardener loosened' | 'Its leaves unfolded gradually during' |
| 21 | 4 | 4 | 0.042 | 'The crew adjusted the rope' | 'A gardener loosened' |
| 27 | 0 | 1 | 0.577 | 'The' | 'A' |
| 27 | 0 | 2 | 0.351 | 'The' | 'Col' |
| 27 | 0 | 3 | 0.022 | 'Col' | 'By' |
| 27 | 0 | 4 | 0.016 | 'St' | 'Several' |
| 27 | 1 | 1 | 0.228 | 'Several leaves' | 'A we' |
| 27 | 1 | 2 | 0.136 | 'Fields and' | 'The image' |
| 27 | 1 | 3 | 0.080 | 'A gard' | 'Other musicians' |
| 27 | 1 | 4 | 0.044 | 'A smooth' | 'Fields and' |
| 27 | 2 | 1 | 0.214 | 'The edges were' | 'A weaver' |
| 27 | 2 | 2 | 0.169 | 'By evening a' | 'Fields and small' |
| 27 | 2 | 3 | 0.103 | 'Its leaves unfolded' | 'A pale gl' |
| 27 | 2 | 4 | 0.061 | 'The edges were' | 'Several leaves turned' |
| 27 | 3 | 1 | 0.243 | 'Some phrases expressed the' | 'Fields and small villages' |
| 27 | 3 | 2 | 0.194 | 'The edges were folded' | 'By evening a light' |
| 27 | 3 | 3 | 0.083 | 'A river carried small' | 'The morning train arrived' |
| 27 | 3 | 4 | 0.064 | 'The edges were folded' | 'The pattern repeated along' |
| 27 | 4 | 1 | 0.290 | 'A smooth wooden surface reflected' | 'The damp ground provided a' |
| 27 | 4 | 2 | 0.214 | 'The edges were folded neatly' | 'A field guide described how' |
| 27 | 4 | 3 | 0.069 | 'The carpenter measured a' | 'The roots need enough space' |
| 27 | 4 | 4 | 0.059 | 'The edges were folded neatly' | 'The melody moved slowly from' |

## F6 mean, PCs and random controls through both heads

| Layer | Position | Direction | Qwen top five | Dolos top five | Shared top20 |
|---:|---:|---|---|---|---:|
| 7 | 0 | mean_delta | ',ch', ',c', ',event', 'cw', 'rr' | ',ch', ',c', ',event', ',str', ',T' | 17 |
| 7 | 0 | pc1_negative | ' limp', 'Serializable', '毒', ' Gorgeous', ' goofy' | ' limp', ' goofy', 'Serializable', '不行', '毒' | 14 |
| 7 | 0 | pc1_positive | '下面是小', '}%', '利用您的', '?$', 'isos' | '下面是小', '}%', '?$', 'isos', ' otherwise' | 15 |
| 7 | 0 | pc2_negative | 'aises', 'ERNEL', 'erais', 'ención', '檫' | 'aises', 'ERNEL', 'ención', 'erais', 'asics' | 17 |
| 7 | 0 | pc2_positive | ' dissertation', 'version', 'UG', 'war', '文' | ' dissertation', 'version', 'UG', '.', 'war' | 16 |
| 7 | 0 | pc3_negative | 'son', 'cover', 'Lang', 'una', 'RI' | 'son', 'Format', '_format', 'una', 'пром' | 16 |
| 7 | 0 | pc3_positive | ' independently', 'íses', ' common', ' integrated', '쟤' | ' independently', ' common', ' integrated', ' years', 'íses' | 15 |
| 7 | 0 | pc4_negative | ' reviewing', 'walking', 'building', '、', 'verture' | ' reviewing', '、', 'walking', 'building', 'verture' | 15 |
| 7 | 0 | pc4_positive | ' eldre', '_Delay', 'シンプ', 'iable', 'isors' | ' eldre', 'acers', 'シンプ', '硌', '_Delay' | 18 |
| 7 | 0 | random1_negative | ' fkk', 'ıdır', 'istique', '📐', ' circle' | ' fkk', 'ıdır', '\|"', 'istique', '📐' | 16 |
| 7 | 0 | random1_positive | '_MAG', 'Mag', ' né', '抑', ' magn' | 'Mag', '_MAG', ' magn', '抑', ' Searches' | 17 |
| 7 | 0 | random2_negative | ' molding', '()>\n', 'YST', 'jumbotron', 'ymb' | ' molding', '()>\n', 'yst', '兰', 'ymb' | 17 |
| 7 | 0 | random2_positive | 'female', 'ступил', '城乡', 'redentials', '爨' | 'female', 'nung', '城乡', 'redentials', 'ступил' | 19 |
| 7 | 0 | random3_negative | 'comp', '-comp', ' Arb', ' demand', '기관' | 'comp', ' Arb', '-comp', ' demand', ' compil' | 17 |
| 7 | 0 | random3_positive | '茚', '的女孩', 'elas', 'Ĥ', 'resses' | '茚', 'elas', '妃', 'oses', 'resses' | 17 |
| 7 | 0 | random4_negative | '[char', ' Stations', 'la', ' Behaviour', 'ictions' | '[char', ' Stations', ' Behaviour', 'la', ' Fra' | 16 |
| 7 | 0 | random4_positive | ' capsule', '监视', ' capsules', '.Executor', '睹' | '监视', ' capsule', 'ley', ' capsules', '.Executor' | 15 |
| 7 | 1 | mean_delta | 'GAN', ' T', 'ﬁ', 'F', 'T' | ' T', 'F', 'T', 'ﬁ', ' &' | 15 |
| 7 | 1 | pc1_negative | 'hell', 'PI', 'lobe', '®', '=edge' | 'hell', 'PI', ' Dom', '-dom', 'lobe' | 17 |
| 7 | 1 | pc1_positive | 'sWith', 'atic', ' Jaune', 'сь', '龁' | 'sWith', ' Jaune', 'atic', 'сь', 'atical' | 15 |
| 7 | 1 | pc2_negative | 'ional', ' phận', 'lider', 'hold', ' interven' | ' phận', 'ional', 'hold', 'lider', 'gang' | 14 |
| 7 | 1 | pc2_positive | '=-=-=-=-=-=-=-=-', '賴', 'nerg', 'airo', 'cke' | '賴', '=-=-=-=-=-=-=-=-', 'woke', 'cke', '(ActionEvent' | 15 |
| 7 | 1 | pc3_negative | 'warts', 'icients', 'uccess', 'ently', 'かい' | 'warts', 'icients', 'uccess', 'ently', '呈' | 16 |
| 7 | 1 | pc3_positive | 'visor', 'respons', '/maps', ' last', '-last' | 'visor', 'respons', '/maps', ' last', '-last' | 18 |
| 7 | 1 | pc4_negative | '衡', '新娘', '和个人', '"${', '设计' | '衡', '新娘', '和个人', '"${', 'waitFor' | 14 |
| 7 | 1 | pc4_positive | '-ish', '.jp', 'uropean', 'eness', 'ness' | '-ish', '.jp', 'uropean', 'sip', 'eness' | 17 |
| 7 | 1 | random1_negative | 'تكن', '__\r\n', 'ayı', 'VOICE', 'ṯ' | 'تكن', 'ayı', 'VOICE', 'ṯ', 'wand' | 14 |
| 7 | 1 | random1_positive | 'ap', 'mas', 'ly', ' pregnant', '(' | 'ap', 'ly', '(', ' pregnant', 'mas' | 17 |
| 7 | 1 | random2_negative | 'za', '沉默', '氨酸', 'โต', 'ersed' | 'za', '氨酸', '沉默', 'โต', '敬业' | 17 |
| 7 | 1 | random2_positive | 'getInstance', ' gör', '萬', 'び', 'тип' | ' gör', 'тип', '万', ' Sq', '萬' | 17 |
| 7 | 1 | random3_negative | '錾', '手下', ' Dort', '经开', '.SaveChangesAsync' | '錾', '手下', ' Dort', '.SaveChangesAsync', ' Interaction' | 18 |
| 7 | 1 | random3_positive | 'uda', 'ounter', '有效性', 'unta', 'emean' | 'uda', 'ounter', 'unta', '有效性', 'uito' | 17 |
| 7 | 1 | random4_negative | 'startIndex', '扇', 'ispers', 'Ć', '广场' | '扇', 'Ć', 'ispers', 'startIndex', '广场' | 19 |
| 7 | 1 | random4_positive | 'vision', 'Api', 'law', 'ref', 'urb' | 'vision', 'Api', 'law', 'urb', 'ref' | 17 |
| 7 | 2 | mean_delta | '/trans', 'ch', 'z', ' ];', ' T' | '/trans', 'ch', 'rub', '炮', ' TG' | 16 |
| 7 | 2 | pc1_negative | 'деся', 'нач', 'cene', 'rax', 'SIM' | 'деся', 'нач', 'eam', 'tos', 'rax' | 17 |
| 7 | 2 | pc1_positive | 'ся', 'ly', 'led', 'lessly', 'о' | 'ся', 'led', 'lessly', 'о', 'ly' | 17 |
| 7 | 2 | pc2_negative | 'falls', '爷', 'ium', '的', 'zilla' | 'falls', '爷', 'DMETHOD', '的', 'zilla' | 18 |
| 7 | 2 | pc2_positive | 'ي', 'tom', ' mrb', 'sWith', '口号' | 'ي', 'tom', 'sWith', 'iska', 'elig' | 18 |
| 7 | 2 | pc3_negative | '/ge', '牍', ' والن', '富民', 'les' | '/ge', '牍', ' والن', ' Tie', '!' | 14 |
| 7 | 2 | pc3_positive | 'prung', 'umbo', 'UMB', '_MetaData', ' pobliżu' | 'umbo', 'prung', 'UMB', 'ibur', '_MetaData' | 17 |
| 7 | 2 | pc4_negative | 'unfinished', 'primary', 'eps', 'singular', '了自己的' | 'eps', 'unfinished', 'singular', ' secondary', '�单' | 16 |
| 7 | 2 | pc4_positive | 'orc', ' dong', '发言人', 'óm', '/sdk' | 'orc', ' dong', ',\n\n\n\n', '券', '/sdk' | 17 |
| 7 | 2 | random1_negative | 'ışı', 'ecast', ' ksi', '柁', 'ланд' | '柁', 'ecast', 'ışı', ' ksi', 'ланд' | 17 |
| 7 | 2 | random1_positive | '皿', ' classifier', '1', ' bin', ' builder' | ' classifier', '皿', '1', ' builder', ' bin' | 16 |
| 7 | 2 | random2_negative | 'iale', 'iative', 'pite', 'enne', 'nz' | 'pite', 'iale', 'enne', 'iative', 'nz' | 20 |
| 7 | 2 | random2_positive | 'abay', '伝え', 'ста', '仅代表', ' Resolver' | 'abay', '伝え', '邋', '仅代表', '/OR' | 14 |
| 7 | 2 | random3_negative | 'ackers', 'amer', 'ery', ' Usa', '笏' | 'amer', 'ackers', 'ery', ' Wenger', ' Usa' | 16 |
| 7 | 2 | random3_positive | 'lee', ' moons', '堕', 'otic', 'mania' | 'lee', 'mania', ' moons', ' duties', '堕' | 16 |
| 7 | 2 | random4_negative | 'ernes', 'zers', '",-', 'engl', '：</' | '：</', 'ernes', 'zers', 'engl', '",-' | 17 |
| 7 | 2 | random4_positive | 'previous', '力还是', '这样的话', ' previous', '而且还' | '力还是', '这样的话', 'iram', 'previous', '棍' | 15 |
| 7 | 3 | mean_delta | 'cy', 'tz', 'spe', '队', 's' | 'cy', 'spe', 'tz', '队', '��' | 15 |
| 7 | 3 | pc1_negative | 'alls', 'ames', ' Hale', '的', '酶' | 'alls', 'ames', '的', 'Develop', '(separator' | 17 |
| 7 | 3 | pc1_positive | 'sWith', 'ي', '/GPL', ' disguise', 'сь' | 'sWith', '/GPL', 'можем', 'сь', 'ي' | 17 |
| 7 | 3 | pc2_negative | 'lessly', 'ly', 'liness', 'led', 'less' | 'lessly', 'ly', 'liness', 'led', 'less' | 18 |
| 7 | 3 | pc2_positive | 'деся', 'ỉnh', '.dtd', 'odate', 'oundary' | 'деся', 'ỉnh', 'odate', '.dtd', 'oundary' | 15 |
| 7 | 3 | pc3_negative | ' hues', '-orange', 'ptoms', '地带', ' bulbs' | ' hues', ',\n\n', '-orange', ' yell', '地带' | 16 |
| 7 | 3 | pc3_positive | '默契', 'abinet', ' Legend', ' Statistics', ' statistics' | 'abinet', '默契', ' Legend', ' Statistics', '机' | 18 |
| 7 | 3 | pc4_negative | '{$', '_Checked', 'otope', 'ไข', 'otechn' | '{$', 'otope', '_Checked', " '{@", 'iteDatabase' | 17 |
| 7 | 3 | pc4_positive | 'stalk', ';;;;;;;;', 'ąd', 'Suggestions', 'ensis' | ';;;;;;;;', 'stalk', 'aware', 'ąd', 'ensis' | 15 |
| 7 | 3 | random1_negative | 'udios', 'erule', 'schedule', 'OutOfRangeException', 'GLE' | 'udios', '阏', 'erule', 'schedule', 'GLE' | 16 |
| 7 | 3 | random1_positive | 'es', 's', 'gate', ' t', ' leg' | 'es', ' leg', 's', 'gate', ' T' | 17 |
| 7 | 3 | random2_negative | 'atel', ' imm', 'ystate', 'vj', 'imits' | 'atel', ' imm', 'ystate', 'vj', ' resett' | 16 |
| 7 | 3 | random2_positive | '.isPresent', 'ERV', 'uilder', ' Sol', 'hma' | '.isPresent', 'ERV', 'uilder', ' Sol', 'hma' | 17 |
| 7 | 3 | random3_negative | 'RESP', 'rag', ' skating', '辜', '甲状' | 'rag', '辜', 'RESP', 'anmar', 'ollen' | 14 |
| 7 | 3 | random3_positive | 'ewing', '��', '辕', '前所', 'ccd' | 'ewing', '��', '前所', '`);\n\n', '辕' | 16 |
| 7 | 3 | random4_negative | ' bare', ' deposit', 'max', 'отов', 'ration' | ' bare', ' deposit', 'ateria', '�', 'Assets' | 16 |
| 7 | 3 | random4_positive | 'arial', 'ENER', 'egasus', ' tostring', ' indexing' | 'arial', ' YE', '">\'\n', "']]]\n", ' indexing' | 14 |
| 7 | 4 | mean_delta | 'tur', 'cou', 'y', 'r', " '" | 'cou', 'tur', 'y', ' L', 'V' | 16 |
| 7 | 4 | pc1_negative | 'ALK', '爷', 'wave', ' anatomy', 'trl' | 'ALK', '爷', 'ISH', 'wave', '的' | 17 |
| 7 | 4 | pc1_positive | 'ي', '-labelledby', '/GPL', '半岛', 'inery' | 'ي', '/GPL', '-labelledby', 'inery', 'sWith' | 16 |
| 7 | 4 | pc2_negative | 'tos', ' Plain', ' Lama', 'tà', 'inth' | 'tos', 'tà', ' Lama', 'кос', '/head' | 13 |
| 7 | 4 | pc2_positive | 'lessly', 'Violation', 'ly', 'ся', 'atic' | 'lessly', 'Violation', '🏠', 'imony', 'ся' | 18 |
| 7 | 4 | pc3_negative | '页', 'area', '喇', '驾', '证' | '页', 'area', '喇', 'ense', '驾' | 18 |
| 7 | 4 | pc3_positive | 'inherits', 'ittest', 'sdale', 'ransition', 'دين' | 'sdale', 'inherits', 'ransition', 'ittest', 'upil' | 19 |
| 7 | 4 | pc4_negative | '/book', 'blem', ' Cres', ' chall', 'alte' | '/book', ' Cres', 'blem', ' chall', 'bul' | 17 |
| 7 | 4 | pc4_positive | 'inine', 'idders', '其它问题', 'rones', 'OrNil' | 'inine', 'rones', 'OrNil', 'ıdır', ' ๆ' | 17 |
| 7 | 4 | random1_negative | '这部', '讹', '@api', 'óst', 'fram' | '这部', '讹', '@api', ' Float', 'mares' | 16 |
| 7 | 4 | random1_positive | 'AGED', 'itational', 'tog', '<X', 'Redirect' | 'AGED', '<X', 'Redirect', 'tog', ' ambiguity' | 17 |
| 7 | 4 | random2_negative | ')(__', ' forsk', '".\n\n\n\n', '/loading', '突击' | ')(__', ' forsk', '/loading', 'ichtet', '突击' | 17 |
| 7 | 4 | random2_positive | 'pper', 'urr', '附属', 'udem', 'MM' | 'pper', 'urr', '附属', 'MM', 'cem' | 15 |
| 7 | 4 | random3_negative | 'moid', '关于我们', '.await', 'DES', '珞' | 'moid', '关于我们', 'DES', '.await', ' *)__' | 18 |
| 7 | 4 | random3_positive | 'ensing', '禮', ' Alger', '会长', ' penetr' | 'ensing', '禮', '会长', ' penetr', 'Mag' | 17 |
| 7 | 4 | random4_negative | '劳', ' hazard', 'Thin', 'allis', '卫' | '劳', 'Thin', 'нец', ' hazard', '卫' | 18 |
| 7 | 4 | random4_positive | 'icle', 'imagin', ' believing', ' paran', 'onde' | 'imagin', ' believing', 'icle', 'onica', ' emotionally' | 15 |
| 14 | 0 | mean_delta | ',ch', ',c', ',tmp', ',event', ',str' | ',ch', ',c', ',str', ',event', ',T' | 17 |
| 14 | 0 | pc1_negative | ' limp', '毒', 'Serializable', ' Gorgeous', ' goofy' | ' limp', ' goofy', '不行', 'Serializable', '毒' | 14 |
| 14 | 0 | pc1_positive | '下面是小', '}%', '利用您的', '?$', 'isos' | '下面是小', '}%', '?$', ' otherwise', 'isos' | 15 |
| 14 | 0 | pc2_negative | ' dissertation', 'war', 'version', 'UG', 'cre' | ' dissertation', 'version', 'war', 'UG', 'cred' | 18 |
| 14 | 0 | pc2_positive | 'aises', 'ERNEL', 'erais', 'ención', 'áticas' | 'aises', 'ención', 'ERNEL', 'áticas', 'asions' | 17 |
| 14 | 0 | pc3_negative | 'son', 'apel', 'Lang', '.lang', '_format' | 'son', '_format', 'apel', 'Format', 'Lang' | 17 |
| 14 | 0 | pc3_positive | ' independently', ' newly', ' common', ' joint', ' car' | ' independently', ' common', ' newly', ' joint', ' car' | 18 |
| 14 | 0 | pc4_negative | ' reviewing', 'verture', 'val', 'walking', 'form' | ' reviewing', '、', 'walking', 'verture', 'form' | 15 |
| 14 | 0 | pc4_positive | 'シンプ', 'acers', 'iable', '硌', 'isors' | 'acers', 'シンプ', '硌', 'iable', 'isors' | 18 |
| 14 | 0 | random1_negative | 'hir', 'subtract', 'anter', 'ieber', 'iang' | 'hir', 'anter', 'subtract', 'ieber', 'iang' | 16 |
| 14 | 0 | random1_positive | 'stances', '昧', ' LOT', ' scope', 'scope' | 'stances', ' LOT', '昧', ' scope', '四方' | 17 |
| 14 | 0 | random2_negative | ':get', '-toggler', ' beg', 'acia', '-chevron' | ' beg', ':get', '-toggler', 'get', '绊' | 18 |
| 14 | 0 | random2_positive | '"]){\n', '每个人', ' BALL', 'HEEL', 'fu' | 'HEEL', 'fu', '每个人', ' honda', 'eft' | 18 |
| 14 | 0 | random3_negative | 'repository', 'asher', 'room', 'Stage', ' repository' | 'repository', 'room', 'asher', 'Stage', 'ilation' | 18 |
| 14 | 0 | random3_positive | '深远', 'DEN', ' Within', 'uffs', '为您' | ' Within', '深远', 'Within', 'DEN', '为您' | 17 |
| 14 | 0 | random4_negative | '�', 'pty', 'opy', ' Voor', 'ouri' | '�', 'opy', 'pty', '的成本', ' Voor' | 16 |
| 14 | 0 | random4_positive | 'Card', ' Card', 'Cards', ' nar', '#index' | 'Card', ' nar', ' Card', 'Cards', ' implicit' | 15 |
| 14 | 1 | mean_delta | '級', 'рев', 'burn', 'r', ' "";\r\n' | 'burn', ' "";\r\n', '級', 'рев', 'r' | 15 |
| 14 | 1 | pc1_negative | 'et', '/', 'est', '\|', ' morphology' | 'et', '/', 'lingen', '\|', ' morphology' | 18 |
| 14 | 1 | pc1_positive | 'sWith', 'ɴ', 'edException', 'atic', 'rious' | 'sWith', 'ɴ', 'edException', 'rious', '艰辛' | 17 |
| 14 | 1 | pc2_negative | ' vidé', 'tering', 'finalize', '这种情况', ' poste' | ' vidé', '这种情况', 'tering', 'finalize', 'ายน' | 16 |
| 14 | 1 | pc2_positive | '(es', '/to', 'يب', '社会责任', ' Liber' | '/to', '(es', 'يب', ' Liber', '社会责任' | 17 |
| 14 | 1 | pc3_negative | '桑', 'ional', 'fund', ' fund', ' Sang' | '桑', 'ional', 'fund', ' Sang', 'gang' | 15 |
| 14 | 1 | pc3_positive | '晰', '咻', 'suite', 'cke', 'nerg' | '晰', '咻', 'suite', 'cke', 'NodeType' | 15 |
| 14 | 1 | pc4_negative | 'ProgressBar', '前途', 'anding', 'cession', 'ISTS' | '前途', 'ProgressBar', 'anding', 'erdem', 'lte' | 15 |
| 14 | 1 | pc4_positive | '基础上', 'iom', 'orial', ' assort', '说什么' | 'iom', 'orial', '基础上', ' assort', '说什么' | 16 |
| 14 | 1 | random1_negative | 'oints', 'ombat', '狼', '怀抱', '捆绑' | 'oints', 'ombat', '狼', '怀抱', '大家分享' | 18 |
| 14 | 1 | random1_positive | ' appearances', '_nc', '悛', '...\n\n\n\n', 'eness' | ' appearances', '_nc', 'eness', '...\n\n\n\n', ' resemblance' | 15 |
| 14 | 1 | random2_negative | 'apus', '公报', ' Justi', 'OUCH', 'bookmark' | 'apus', '公报', 'bookmark', 'OUCH', '-cache' | 17 |
| 14 | 1 | random2_positive | 'ima', 'im', 'imet', 'imat', 'imilar' | 'ima', 'im', 'imet', 'imilar', 'plit' | 15 |
| 14 | 1 | random3_negative | 'tür', ' nuru', 'iros', '_chance', ' sürecin' | ',\n\n', ' nuru', ',\n\n\n\n', 'ombres', '_chance' | 15 |
| 14 | 1 | random3_positive | 'aho', 'yl', ' Pag', '�', 'ahr' | 'aho', 'yl', ' Pag', ' Auth', 'ahr' | 18 |
| 14 | 1 | random4_negative | '边界', '下半', ' Gate', ' marg', '降' | '边界', ' Gate', '下半', ' marg', 'rolled' | 17 |
| 14 | 1 | random4_positive | 'ilities', ' crackers', '手动', '_velocity', ' RaisedButton' | 'ilities', ' crackers', '手动', 'ython', ' Freem' | 12 |
| 14 | 2 | mean_delta | 'n', 'r', '_fsm', 's', '/trans' | 'r', 'n', '_fsm', '/trans', '=[]\r\n' | 16 |
| 14 | 2 | pc1_negative | 'нач', 'ことができる', 'ative', 's', 'hx' | 'нач', 's', 'деся', 'hx', 'ことができる' | 17 |
| 14 | 2 | pc1_positive | '#__', 'atic', 'led', 'ся', 'ly' | '#__', 'led', 'atic', 'ся', ' Woo' | 18 |
| 14 | 2 | pc2_negative | 'boarding', 'alive', 'falls', 'stood', '爷' | 'alive', 'stood', 'boarding', '爷', 'vest' | 16 |
| 14 | 2 | pc2_positive | 'ي', 'iska', 'sWith', 'toJson', '蹇' | 'ي', 'iska', 'toJson', 'itzer', ' Thur' | 17 |
| 14 | 2 | pc3_negative | ' can', '能把', '要做好', ' cap', '帽' | ' can', '能把', '要做好', ' cap', 'work' | 15 |
| 14 | 2 | pc3_positive | 'sar', 'woke', 'EFR', 'volução', 'ependency' | 'sar', 'woke', 'URING', 'volução', 'хож' | 17 |
| 14 | 2 | pc4_negative | '/blue', ' aged', '/ge', 'sit', '高达' | '/blue', ' aged', '/ge', 'peq', '和服务' | 15 |
| 14 | 2 | pc4_positive | 'eways', ' Contributors', '矢', '蹼', '-Trump' | 'eways', ' Contributors', '矢', 'eron', '-Trump' | 19 |
| 14 | 2 | random1_negative | 'Combat', 'append', 'Ne', 'atal', ' neurological' | 'Combat', 'append', 'Ne', '粟', ' neurological' | 15 |
| 14 | 2 | random1_positive | 'ffen', 'ADR', 'enie', 'uder', 'ıc' | 'ADR', 'enie', 'ffen', 'uder', 'itti' | 19 |
| 14 | 2 | random2_negative | 'le', 'ApplicationBuilder', 'figures', 'arend', '网友评论' | 'le', 'ApplicationBuilder', 'figures', ' rendez', '(:,:,' | 15 |
| 14 | 2 | random2_positive | '.alt', '弹', 'Bars', 'usher', 'änger' | '.alt', '弹', 'Bars', 'usher', 'oday' | 18 |
| 14 | 2 | random3_negative | 'compressed', 'nesia', ' nin', 'AppComponent', ' pige' | 'compressed', 'nesia', 'nite', ' pige', ' anti' | 15 |
| 14 | 2 | random3_positive | "')\n\n", '/value', ' expression', "'):\n", '})();' | "')\n\n", ' expression', "'):\n", 'Expression', '/value' | 16 |
| 14 | 2 | random4_negative | '社会保障', ' Initializes', 'Dt', '档次', 'comment' | '社会保障', 'Dt', '档次', ' qualifier', 'comment' | 16 |
| 14 | 2 | random4_positive | 'iado', 'IEWS', 'урс', ' hovered', '想起来' | 'iado', 'IEWS', '想起来', ' hovered', 'урс' | 19 |
| 14 | 3 | mean_delta | 's', 'tz', 'n', 'r', 'yh' | 's', 'n', 'tz', 'r', 'yh' | 15 |
| 14 | 3 | pc1_negative | '性命', 'rijk', ' Night', ' Ease', 'нач' | '性命', 'rijk', ' Night', 'HK', 'kie' | 14 |
| 14 | 3 | pc1_positive | 'sWith', 'ي', '看待', '<![', 'сь' | 'sWith', '看待', 'TED', '<![', 'ي' | 16 |
| 14 | 3 | pc2_negative | '�', 'oundary', '临近', 'деся', 'dere' | '�', 'деся', 'tap', 'dere', 'oundary' | 16 |
| 14 | 3 | pc2_positive | 'ся', 'uff', 'Islam', 'ifies', '.setHorizontalGroup' | '.setHorizontalGroup', 'uff', 'Islam', 'ся', 'LOS' | 17 |
| 14 | 3 | pc3_negative | '在线', '/install', ' mission', ' online', '\\Component' | ' mission', '/install', '\\Component', '在线', ' online' | 17 |
| 14 | 3 | pc3_positive | 'agus', 'wright', 'odore', 'odate', 'phin' | 'agus', 'wright', 'ationToken', 'odore', 'odate' | 16 |
| 14 | 3 | pc4_negative | 'اغ', 'onso', '不认识', '方式进行', 'Reply' | 'onso', '不认识', 'اغ', '方式进行', 'Reply' | 16 |
| 14 | 3 | pc4_positive | '.family', 'atican', '交会', ' relocated', 'アイテム' | '.family', 'atican', ' relocated', '交会', 'oined' | 18 |
| 14 | 3 | random1_negative | '候', 'icals', ' Sala', 'SQ', '钣' | '候', 'icina', 'SQ', 'icals', 'inja' | 15 |
| 14 | 3 | random1_positive | '广播', ' bordel', 'regn', 'encer', 'dist' | '广播', ',\n\n', 'regn', ' bordel', ' dist' | 15 |
| 14 | 3 | random2_negative | ' )->', 'INES', 'ines', '())->', '.Tree' | ' )->', 'INES', 'ines', ' loos', 'erties' | 17 |
| 14 | 3 | random2_positive | 'abox', 'MN', '音', 'DataExchange', 'abee' | 'abox', 'MN', 'abee', '音', 'uld' | 15 |
| 14 | 3 | random3_negative | 'BOSE', '怎么说', '#if', '.format', '文' | 'BOSE', '#if', '怎么说', '.format', 'Ast' | 15 |
| 14 | 3 | random3_positive | '塍', 'ếm', ' Dịch', 'FACT', '/il' | '塍', 'ếm', ' triển', ' CONTEXT', '/il' | 17 |
| 14 | 3 | random4_negative | '增强', 'tone', 'ellite', 'enh', '随' | '增强', 'tone', '随', 'enh', 'ellite' | 14 |
| 14 | 3 | random4_positive | 'hood', '岑', ' Tus', ' critical', 'ox' | 'hood', ' Tus', '岑', ' critical', 'ox' | 18 |
| 14 | 4 | mean_delta | 'y', 'yh', 'yb', 'r', 'yk' | 'y', 'yh', 'yb', 'r', 'yk' | 17 |
| 14 | 4 | pc1_negative | '爷', 'elsey', 'DMETHOD', ' anatomy', '川' | 'elsey', '爷', 'DMETHOD', 'plit', 'wave' | 15 |
| 14 | 4 | pc1_positive | 'ي', 'сь', 'tom', 'tees', '-labelledby' | 'ي', 'сь', 'tom', 'tees', '/GPL' | 17 |
| 14 | 4 | pc2_negative | 'деся', 'tin', 'IEWS', 'cq', 'pig' | 'деся', 'pig', 'lus', 'IEWS', 'cq' | 17 |
| 14 | 4 | pc2_positive | 'atic', 'ly', 'о', 'ся', ' útil' | 'atic', 'OST', 'ся', ' útil', 'о' | 16 |
| 14 | 4 | pc3_negative | '@', 'irs', 'ky', '件', '再去' | '@', 'irs', 'ky', ' Black', '再去' | 16 |
| 14 | 4 | pc3_positive | 'ウォー', ' downloads', '.PI', 'AdminController', ' télécharg' | 'ウォー', ' downloads', '.PI', 'AdminController', '.);\n' | 17 |
| 14 | 4 | pc4_negative | '的投资', '@m', '的食物', '蹈', ' Algebra' | '的投资', '的食物', '@m', ' chữa', '是韩国' | 17 |
| 14 | 4 | pc4_positive | '爹', '外界', '/off', '缕', 'nds' | '爹', '/off', '外界', 'standing', 'lus' | 17 |
| 14 | 4 | random1_negative | '一角', '网首页', ')))));\r\n', 'Sharper', 'reeNode' | '一角', '网首页', 'Sharper', '多い', 'esters' | 17 |
| 14 | 4 | random1_positive | ' Mint', ' Kis', 'iens', '依托', 'lias' | ' Mint', 'iens', 'lias', 'ries', '依托' | 15 |
| 14 | 4 | random2_negative | 'ynos', 'YLE', 'matchCondition', '星辰', 'threads' | 'YLE', 'ynos', 'matchCondition', 'threads', '星辰' | 16 |
| 14 | 4 | random2_positive | 'ucht', '奥', 'tement', 'ights', 'ierge' | 'ucht', '奥', 'tement', 'ights', 'ierge' | 15 |
| 14 | 4 | random3_negative | 'jni', '(LL', 'uong', '(Encoding', '(LP' | '(LL', 'jni', 'uong', 'ipsis', '(Encoding' | 18 |
| 14 | 4 | random3_positive | 'Data', 'otics', ' infinit', 'frame', 'MOST' | 'otics', 'Data', ' infinit', 'frame', 'erm' | 17 |
| 14 | 4 | random4_negative | 'istributed', 'mium', 'ottle', 'olle', ' gravid' | 'istributed', ' gravid', 'olle', ' DISTRIBUT', 'ottle' | 17 |
| 14 | 4 | random4_positive | 'ener', '是什么呢', 'liner', ' Builder', 'sources' | 'ener', 'sources', '动力', '.sources', '是什么呢' | 18 |
| 21 | 0 | mean_delta | ',ch', ',c', ',tmp', ',module', ',copy' | ',ch', ',c', ',str', ',copy', ',module' | 17 |
| 21 | 0 | pc1_negative | ' limp', 'Serializable', '毒', ' Gorgeous', ' goofy' | ' limp', ' goofy', '不行', 'Serializable', '毒' | 14 |
| 21 | 0 | pc1_positive | '下面是小', '}%', '利用您的', '?$', '@endsection' | '下面是小', '}%', '?$', ' otherwise', 'isos' | 15 |
| 21 | 0 | pc2_negative | ' dissertation', 'version', 'war', 'UG', 'cred' | ' dissertation', 'version', 'UG', 'cred', 'war' | 17 |
| 21 | 0 | pc2_positive | 'aises', 'ERNEL', 'áticas', 'ención', '阂' | 'aises', 'ERNEL', '阂', 'ención', 'áticas' | 16 |
| 21 | 0 | pc3_negative | 'son', '/lang', 'Lang', '.lang', 'apel' | 'son', '_format', 'пром', 'Lang', 'apel' | 16 |
| 21 | 0 | pc3_positive | ' independently', ' newly', ' common', ' car', ' years' | ' independently', ' common', ' car', ' years', ' newly' | 18 |
| 21 | 0 | pc4_negative | ' reviewing', 'verture', 'walking', 'val', 'allen' | ' reviewing', 'walking', 'verture', '��', '、' | 14 |
| 21 | 0 | pc4_positive | 'シンプ', '硌', 'acers', 'iable', ' eldre' | '硌', 'シンプ', 'acers', ' fois', ' eldre' | 17 |
| 21 | 0 | random1_negative | 'ilot', ' Eg', '睡前', ' Regardless', ' instance' | 'ilot', ' Eg', '睡前', ' Pros', ' Module' | 17 |
| 21 | 0 | random1_positive | '�', ' atIndex', '��', ' Tennis', 'okit' | '�', '��', ' atIndex', '<Player', "',{" | 15 |
| 21 | 0 | random2_negative | ' Bul', '"struct', '泐', ' removeObject', '.ver' | ' removeObject', ' Bul', '"struct', '泐', ' Hom' | 15 |
| 21 | 0 | random2_positive | 'beck', 'alian', 'vae', 'upro', 'ooks' | 'beck', 'alian', 'vae', 'upro', 'ooks' | 16 |
| 21 | 0 | random3_negative | 'ars', 'agas', '冠', '民主', '侈' | 'ars', 'agas', '冠', 'rights', ' sede' | 16 |
| 21 | 0 | random3_positive | 'oming', 'ạc', 'ometry', 'omen', 'reflection' | 'oming', 'ạc', 'ometry', '敲', ' om' | 16 |
| 21 | 0 | random4_negative | '.Thread', '轩', '阊', 'pyx', 'odyn' | '轩', '.Thread', '阊', 'pyx', 'odyn' | 18 |
| 21 | 0 | random4_positive | '硪', 'Balancer', '평가', '/catalog', 'obil' | '평가', '硪', 'Balancer', 'obil', 'ycles' | 15 |
| 21 | 1 | mean_delta | '級', '\r\n\t\r\n', '\r\n\t\t\r\n', 'codes', 'l' | '級', '\r\n\t\r\n', 'codes', '\r\n\t\t\r\n', 'l' | 18 |
| 21 | 1 | pc1_negative | ' faithfully', ' …', ' following', '\xa0', ' youth' | ' faithfully', '团委', ' following', ' canon', ' youth' | 15 |
| 21 | 1 | pc1_positive | 'htable', 'lingen', '一半', ' kaufen', '面积' | 'lingen', 'htable', ' kaufen', '.appspot', '一半' | 16 |
| 21 | 1 | pc2_negative | 'arium', 'ophobia', ' Pirate', 'atic', 'beautiful' | 'arium', 'ophobia', ' Pirate', 'beautiful', 'rical' | 17 |
| 21 | 1 | pc2_positive | 's', 'ystems', ' \u200b\u200b', '-dom', '>' | 's', '-dom', 'ystems', ' \u200b\u200b', 'creen' | 18 |
| 21 | 1 | pc3_negative | '然', 'cribed', ' abaixo', 'semblies', 'amples' | '然', 'cribed', 'amples', 'semblies', ' abaixo' | 17 |
| 21 | 1 | pc3_positive | 'деся', 'esion', 'fans', ' moder', '(pad' | 'деся', 'esion', 'fans', '(pad', ' pains' | 18 |
| 21 | 1 | pc4_negative | 'hip', 'pipe', 'ering', 'itecture', 'يب' | 'hip', 'pipe', '够', 'يب', 'ering' | 19 |
| 21 | 1 | pc4_positive | "__':\r\n", 'ously', 'RuleContext', '～\n\n', 'ogue' | "__':\r\n", 'ously', 'RuleContext', '～\n\n', 'ogue' | 15 |
| 21 | 1 | random1_negative | 'ray', ' Enumerator', 'enaire', ' znalaz', ' Airbus' | ' Enumerator', 'enaire', 'mil', ' znalaz', ' enum' | 15 |
| 21 | 1 | random1_positive | '办', 'Occ', 'InstanceOf', 'ISTORY', 'ocrates' | '办', 'Occ', ' tighter', 'InstanceOf', 'ocrates' | 16 |
| 21 | 1 | random2_negative | 'ulia', '瓜', '�', 'afd', '”:' | 'ulia', '瓜', '�', 'ILA', '菘' | 15 |
| 21 | 1 | random2_positive | 'QUENCY', '逻', 'erdale', 'جي', '噌' | 'QUENCY', 'erdale', '逻', '噌', 'جي' | 17 |
| 21 | 1 | random3_negative | '-beta', 'ciąg', 'furt', '�', '重要' | '-beta', 'furt', 'ciąg', ' Wet', '�' | 14 |
| 21 | 1 | random3_positive | 'le', 'edList', 'iem', 'ed', 'edException' | 'le', 'iem', 'edList', 'edImage', 'ed' | 18 |
| 21 | 1 | random4_negative | 'enumerator', 'ULD', 'UDA', 'ICI', '缇' | 'enumerator', 'UDA', 'ICI', 'ULD', '_reading' | 18 |
| 21 | 1 | random4_positive | '自然', '终身', '!', ' natural', '天然' | '自然', '!', ' natural', '天然', ' today' | 18 |
| 21 | 2 | mean_delta | ' PG', '\r\n\t\r\n', '<?\n', 'l', '\r\n\t\t\r\n' | '\r\n\t\r\n', '<?\n', ' PG', '\r\n\t\t\r\n', 'l' | 18 |
| 21 | 2 | pc1_negative | '�', 'tos', 'деся', ' HttpHeaders', 'SIM' | '�', 'tos', 'деся', ' HttpHeaders', 'SIM' | 15 |
| 21 | 2 | pc1_positive | '#__', 'ly', 'о', 'bright', 'ся' | '#__', '="__', 'bright', 'о', 'ся' | 14 |
| 21 | 2 | pc2_negative | 'b', 'p', 'red', '绿色', 'lobe' | 'p', 'b', '绿色', ' into', 'red' | 15 |
| 21 | 2 | pc2_positive | '尽力', 'FTA', '抟', '回头', '嘘' | 'FTA', '尽力', 'isko', 'ETA', 'сте' | 17 |
| 21 | 2 | pc3_negative | 'e', 'ي', '’s', '(', ' fix' | 'e', '\xa0', '(', ' need', 'ي' | 12 |
| 21 | 2 | pc3_positive | 'ivement', 'ания', 'ffset', 'trl', ' zusätzlich' | 'ания', 'ffset', ',readonly', 'ivement', '范冰' | 16 |
| 21 | 2 | pc4_negative | 'keeper', 'coin', '一则', '商会', '貊' | '商会', 'keeper', '一则', '/arch', 'coin' | 18 |
| 21 | 2 | pc4_positive | 'ibile', '在里面', 'apore', '_filtered', 'tober' | 'ibile', '在里面', 'apore', 'tober', 'nesday' | 18 |
| 21 | 2 | random1_negative | 'RON', '绪', 'stood', 'cano', '[thread' | 'RON', 'cano', '绪', '.currentThread', 'IX' | 17 |
| 21 | 2 | random1_positive | 'opot', 'ency', '�', 'amac', 'encies' | 'opot', 'ency', 'amac', '�', '.Parse' | 17 |
| 21 | 2 | random2_negative | 'ège', ' Ho', '再生', 'elin', ' sessions' | ' Ho', 'ège', '再生', '.damage', 'elin' | 17 |
| 21 | 2 | random2_positive | '_SLAVE', '卻', ' CHARSET', 'ctl', '问道' | '_SLAVE', ' though', ' CHARSET', 'ctl', '卻' | 16 |
| 21 | 2 | random3_negative | 'ROADCAST', 'erner', ' favour', 'xBB', ' Gł' | ' favour', 'ROADCAST', 'erner', ' Gł', 'xBB' | 18 |
| 21 | 2 | random3_positive | '邑', 'robat', 'ities', 'izer', ' +++' | '邑', 'izer', 'robat', 'ities', ' attr' | 17 |
| 21 | 2 | random4_negative | 'ials', 'asti', 'ively', 'rir', 'iode' | 'ials', 'asti', 'rir', '搛', 'ahkan' | 16 |
| 21 | 2 | random4_positive | '摩', '完整性', '上游', '臼', 'ese' | '摩', '完整性', 'ese', '上游', '臼' | 17 |
| 21 | 3 | mean_delta | ' PG', ' pg', '","","', 'gw', ' KM' | ' PG', '","","', ' KM', ' pg', '_\r\n' | 15 |
| 21 | 3 | pc1_negative | 'pedia', 'ly', 'stit', 'ier', '然' | 'pedia', 'stit', 'ly', 'ier', '然' | 14 |
| 21 | 3 | pc1_positive | 'inery', 'ignment', '老人家', 'egrator', '中关' | 'inery', 'ignment', 'egrator', 'ationToken', '老人家' | 15 |
| 21 | 3 | pc2_negative | '�', 'нач', 'alse', '款项', 'iset' | '�', 'нач', 'iset', 'inth', '款项' | 16 |
| 21 | 3 | pc2_positive | 'ся', 'atic', 'stable', 'led', 'imony' | 'ся', 'stable', ";';\n", 'imony', 'fixed' | 15 |
| 21 | 3 | pc3_negative | ' boundaries', ' all', 'all', '_all', ' rendition' | 'all', ' all', ' boundaries', ' rendition', '_all' | 14 |
| 21 | 3 | pc3_positive | ' OPTIONAL', ' BRO', 'PTS', 'NECT', 'unità' | ' BRO', ' OPTIONAL', 'PTS', ' INSTALL', 'quisite' | 14 |
| 21 | 3 | pc4_negative | 'KIT', '…it', '*out', '勉强', ' pleasantly' | 'KIT', '…it', '*out', ' wonderfully', 'rough' | 14 |
| 21 | 3 | pc4_positive | '要坚持', '要加强', '的人来说', ' thermostat', '方式进行' | '要坚持', '要加强', '->$', '的人来说', ' BehaviorSubject' | 15 |
| 21 | 3 | random1_negative | 'spm', 'orners', ' Tử', 'SpinBox', ' Whatsapp' | 'spm', ' Tử', 'orners', 'soever', ' Whatsapp' | 16 |
| 21 | 3 | random1_positive | 'eax', 'ynes', 'ion', '첨', 'enh' | 'ion', 'ynes', 'eax', 'odus', 'ró' | 15 |
| 21 | 3 | random2_negative | 'dds', '锁', ' EN', "'''", '_each' | '锁', 'dds', "'''", '��', 'Four' | 16 |
| 21 | 3 | random2_positive | 'theless', 'subst', 'ect', 'engeance', 'Credits' | 'theless', 'subst', 'ect', 'Credits', 'естественн' | 17 |
| 21 | 3 | random3_negative | ' central', '地坪', ' harmon', 'ASTER', '峡' | ' central', '地坪', ' harmon', '峡', '这首' | 16 |
| 21 | 3 | random3_positive | 'PRESS', '痂', '투', 'eel', 'uger' | 'PRESS', 'eel', '痂', '투', 'uration' | 18 |
| 21 | 3 | random4_negative | 'lot', '\xa0\n', '\xa0', 'ill', 'ims' | 'lot', 'ill', '钩', 'older', '了多少' | 13 |
| 21 | 3 | random4_positive | '下半', 'DOB', 'pare', 'incinnati', 'cco' | 'acd', 'pare', '下半', 'incinnati', 'cco' | 17 |
| 21 | 4 | mean_delta | ' R', ' pg', '[]', ' PG', 'gn' | ' R', '[]', ' pg', ' PG', ' �' | 16 |
| 21 | 4 | pc1_negative | '爷', ' NSMutable', 'berger', 'ely', 'ерт' | '爷', 'berger', 'ely', ' NSCoder', ' NSMutable' | 17 |
| 21 | 4 | pc1_positive | 'ScrollBar', 'ي', 'Digital', '-labelledby', ' Continent' | 'ScrollBar', '-labelledby', 'iska', 'сь', 'Digital' | 13 |
| 21 | 4 | pc2_negative | 'kind', 'деся', 'чем', '�', 'tin' | 'деся', 'чем', '�', 'kind', '/head' | 14 |
| 21 | 4 | pc2_positive | '�', 'atic', 'мар', 'mpz', 'Bootstrap' | '�', ',\\', 'мар', '/wp', 'mpz' | 12 |
| 21 | 4 | pc3_negative | ' many', ' \\"', '距离', ' blocks', ' some' | ' many', ' soil', ' \\"', '距离', ' “' | 16 |
| 21 | 4 | pc3_positive | 'outil', 'contest', 'ospace', 'BCM', ' /*!<' | 'outil', 'contest', 'ospace', 'BCM', 'sar' | 15 |
| 21 | 4 | pc4_negative | 'Ing', 'инд', '质量和', ' Дм', ' withString' | 'инд', ' Дм', 'Ing', '质量和', ' withString' | 18 |
| 21 | 4 | pc4_positive | '々', '\|[', '，默认', ' ____', '宾客' | ' ____', '\|[', '宾客', '々', '；\n' | 14 |
| 21 | 4 | random1_negative | 'Featured', 'SetActive', ' ballet', 'лим', '新闻' | 'Featured', 'SetActive', 'лим', ' ballet', 'brig' | 17 |
| 21 | 4 | random1_positive | 'uli', '(coder', 'pector', '逻', ' mort' | 'pector', 'uli', '(coder', ' mort', ' _:' | 14 |
| 21 | 4 | random2_negative | ' Horn', '戴', '群', ' char', '奈' | ' Horn', '戴', '奈', ' char', '群' | 14 |
| 21 | 4 | random2_positive | ' ("-', 'strand', '呻', '捩', ' licked' | 'strand', ' ("-', '呻', ' licked', 'ENTRY' | 17 |
| 21 | 4 | random3_negative | 'ATUS', '分支', 'ard', 'anches', 'gles' | 'ATUS', '分支', 'gles', 'ard', ' branch' | 14 |
| 21 | 4 | random3_positive | 'reator', 'ast', '.xaml', '汩', 'aster' | 'reator', 'ast', '.xaml', '汩', 'redicate' | 18 |
| 21 | 4 | random4_negative | 'UNCT', 'module', 'emic', 'atrix', ' 开' | 'UNCT', 'module', 'emic', '/update', ' 开' | 14 |
| 21 | 4 | random4_positive | 'isin', 'idge', '倒在', 'InstanceId', 'usa' | 'isin', '倒在', 'idge', 'usa', 'InstanceId' | 17 |
| 27 | 0 | mean_delta | ".'", 'ication', '-bootstrap', 'enido', 'ATTERN' | 'ication', ".'", '-bootstrap', 'unt', 'hint' | 16 |
| 27 | 0 | pc1_negative | '公司', '、', '类', 'IME', '起' | '公司', '、', '类', 'IME', '起' | 15 |
| 27 | 0 | pc1_positive | 'シンプ', '奥地', 'NSS', '澪', 'アメリ' | '奥地', 'シンプ', 'NSS', '澪', 'アメリ' | 18 |
| 27 | 0 | pc2_negative | ' fkk', '的一些', '上的', ' norge', ' danmark' | '的一些', '上的', ' danmark', '而已', '已久的' | 15 |
| 27 | 0 | pc2_positive | ' following', ' graph', ' polynomial', ' equation', ' sequence' | ' following', ' polynomial', ' sequence', ' function', ' equation' | 15 |
| 27 | 0 | pc3_negative | ' amber', ' noting', ' secular', ' junior', ' Jack' | ' amber', ' noting', ' bri', ' junior', ' special' | 17 |
| 27 | 0 | pc3_positive | 'ificate', 'imated', 'roke', 'ypse', 'ewise' | 'roke', 'imated', 'ificate', 'anje', 'tas' | 16 |
| 27 | 0 | pc4_negative | '好消息', ' folders', ' thighs', '*angstrom', ' bearings' | ' folders', ' thighs', '*angstrom', ' bearings', ' futures' | 15 |
| 27 | 0 | pc4_positive | 'ella', 'itz', 'anza', 'acy', 're' | 'anza', 'itz', 'ella', 'acy', 're' | 17 |
| 27 | 0 | random1_negative | 'posit', '澄清', 'itmap', '_filters', ' emptied' | '澄清', 'posit', ' []*', ' emptied', '_filters' | 16 |
| 27 | 0 | random1_positive | '\|r', 'elor', '的话', 'rsp', '镇政府' | '\|r', '的话', 'elor', '镇政府', 'inded' | 18 |
| 27 | 0 | random2_negative | 'ulence', 'elt', '([-', 'greater', 'ew' | 'ulence', '([-', 'elt', 'greater', 'ew' | 15 |
| 27 | 0 | random2_positive | 'EOS', '趺', ' mans', 'closing', 'STACK' | 'EOS', 'aina', 'closing', '趺', '-sale' | 16 |
| 27 | 0 | random3_negative | 'atures', 'atables', 'Missing', 'lo', 'eration' | 'Missing', 'atables', 'lo', 'atures', 'eration' | 13 |
| 27 | 0 | random3_positive | '⻄', 'CAPE', '新人', '转会', 'elage' | 'CAPE', '⻄', ' awaited', '转会', ' Interpreter' | 17 |
| 27 | 0 | random4_negative | 'inz', 'il', ' ', ' Tr', 'inqu' | 'inz', ' Tr', 'il', ' ', 'Tr' | 17 |
| 27 | 0 | random4_positive | 'feeds', '\n    \n    \n', 'thinkable', ' $\r\n', '阏' | 'feeds', '\n    \n    \n', 'thinkable', 'AREN', ' $\r\n' | 17 |
| 27 | 1 | mean_delta | ".'</", "'',", "'</", "''", ".''" | '开元棋牌', 'mPid', 'TRGL', '虎卫', 'spNet' | 1 |
| 27 | 1 | pc1_negative | '\\/', ' \\/', 'ƣ', 'ﬂ', ':\\/\\/' | ' =', ' In', ' +', ' You', ' in' | 2 |
| 27 | 1 | pc1_positive | '\xa0', '\xa0\n', '\xa0\xa0', '\xa0\xa0\xa0\xa0', '\xa0\xa0\xa0' | '.\n\n', ',\n\n', '."\n\n', '".\n\n', '。\n\n' | 0 |
| 27 | 1 | pc2_negative | ' \\"', ',\\"', '�', '<\\/', ' \n\n\n\n' | ',\n\n\n\n', '那', '这个', '这', ' WHICH' | 0 |
| 27 | 1 | pc2_positive | '”.\n\n', '\xa0', '”\n\n', '.”\n\n', '”' | ' (', '”\n\n', '”.\n\n', '.”\n\n', '.\n\n' | 6 |
| 27 | 1 | pc3_negative | '”，', '，“', '’,', ' ’', '”\n' | 'mour', ' SHARE', ' NY', "_',", ' Nass' | 2 |
| 27 | 1 | pc3_positive | '虎卫', '<\|im_end\|>', 'циальн', 'mPid', '岍' | '<\|im_end\|>', '虎卫', '岍', 'mPid', '游戏副本' | 8 |
| 27 | 1 | pc4_negative | '”.', '”?', '[".', '“.', '“They' | ',\n\n\n\n', 'ETERS', '()?>', 'UILT', '();?>' | 0 |
| 27 | 1 | pc4_positive | '\xa0', '\n\n\n\n', "')\n\n\n", '\xa0\n', '\\n' | '**\n\n', '**,', '**\n', ')\n\n', ',' | 0 |
| 27 | 1 | random1_negative | '��', ' favor', 'LIGHT', '各自', '牵引' | '��', ' favor', 'LIGHT', '各自', '牵引' | 15 |
| 27 | 1 | random1_positive | 'erial', '倭', ' glu', '_AST', 'ltra' | 'erial', '倭', '_AST', ' glu', 'ltra' | 15 |
| 27 | 1 | random2_negative | '�数', 'ırken', ' synth', 'öst', 'bose' | '�数', 'bose', ' synth', 'öst', 'ırken' | 16 |
| 27 | 1 | random2_positive | 'ACHI', '起了', '拖', '_QMARK', '贡献' | '起了', 'ACHI', '拖', '贡献', ' kep' | 15 |
| 27 | 1 | random3_negative | ' spells', '--)', ' "--', 'VIRTUAL', '菹' | ' spells', ' "--', 'VIRTUAL', '--)', 'length' | 19 |
| 27 | 1 | random3_positive | '而', '城乡', ' while', '巷', '-ret' | '而', '城乡', '_while', ' […]\n\n', ' BN' | 16 |
| 27 | 1 | random4_negative | '”?', '？”', '()?', '?”', '?”\n\n' | '”?', '？”', 'erness', 'isure', '?\n\n\n' | 16 |
| 27 | 1 | random4_positive | ' Nack', 'dbo', '.VALUE', '铎', 'fo' | 'dbo', ' Nack', '.VALUE', 'fo', '铎' | 16 |
| 27 | 2 | mean_delta | '----------</', '&nbsp', ".'</", '-------------</', "''" | 'mPid', 'ߗ', '法师职业', 'spNet', '游戏副本' | 5 |
| 27 | 2 | pc1_negative | '“(', '"...', '..."', '“.', '”.' | ' In', ' ', ' and', 'In', ' En' | 0 |
| 27 | 2 | pc1_positive | '\xa0', '\xa0\n', '\xa0\xa0', '\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0', '\xa0\xa0\xa0\xa0' | ',\n\n', ',\n', '.,\n', '，\n\n', '，\n' | 1 |
| 27 | 2 | pc2_negative | '\xa0', '\xa0\n', '\xa0\xa0', '\xa0\xa0\xa0', '\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0' | '.\n\n', '.”\n\n', '."\n\n', '”.\n\n', '”\n\n' | 5 |
| 27 | 2 | pc2_positive | '<\\/', '�', '\\/', ' \\"', ',\\"' | ',\n\n\n\n', ' Which', ' which', 'Which', '这个' | 0 |
| 27 | 2 | pc3_negative | '游戏副本', 'mPid', 'ȃ', 'ḋ', 'charAt' | '游戏副本', 'mPid', '岍', '郈', '潩' | 6 |
| 27 | 2 | pc3_positive | '.”\n', '”\n', '”，', '”.\n\n', '”.' | '👋', '🛑', '.";\n', '⛔', '🔄' | 0 |
| 27 | 2 | pc4_negative | '\xa0', "...'", '\xa0\xa0', '\xa0\xa0\xa0\xa0', '\xa0\xa0\xa0' | '.).', '.', '.".', '".', '!.' | 2 |
| 27 | 2 | pc4_positive | '，“', '”—', ' “', '“', ',”' | ',\n\n', ',\r\n', ',\r\n\r\n', ';\r\n\r\n', ';\r\n' | 0 |
| 27 | 2 | random1_negative | 'اري', 'elman', 'TER', ' Soup', ' Called' | 'اري', 'elman', 'TER', ' Soup', 'tring' | 16 |
| 27 | 2 | random1_positive | 'updates', 'igi', '意义', 'oksen', ':update' | 'updates', 'igi', 'oksen', ' meanings', '意义' | 16 |
| 27 | 2 | random2_negative | ' newIndex', '.Rem', 'mos', 'iere', 'ton' | ' newIndex', '.Rem', 'iere', ' sideways', ' SIDE' | 17 |
| 27 | 2 | random2_positive | '化的', '籍', 'Alchemy', '化', 'EDA' | 'Alchemy', '化的', '化', '籍', 'EDA' | 17 |
| 27 | 2 | random3_negative | 'アウ', 'urator', '哺', ' createState', '<*' | 'アウ', '哺', 'urator', '_CLOSED', '母' | 16 |
| 27 | 2 | random3_positive | '厥', ' passphrase', 'intersection', ' i', '刹' | '刹', '厥', ' i', ' passphrase', '.coin' | 17 |
| 27 | 2 | random4_negative | 'パパ活', 'iten', '缲', 'Portrait', ' respons' | 'iten', '缲', ' algebra', 'パパ活', 'Portrait' | 15 |
| 27 | 2 | random4_positive | 'pts', ' pool', ' pools', 'pta', '_IMP' | 'pts', ' pool', ' pools', '_IMP', 'pta' | 19 |
| 27 | 3 | mean_delta | 'ߗ', '游戏副本', '法师职业', 'mPid', '单职业' | 'ߗ', 'ߕ', 'mPid', '觟', '游戏副本' | 15 |
| 27 | 3 | pc1_negative | '“(', '”.', '”', '\\_', '…”' | ' and', ' и', 'และ', '和', ' và' | 0 |
| 27 | 3 | pc1_positive | '\n\n\n\n', ',\n\n\n\n', '\n\n\n\n\n', ',\\"', '\n\n\n' | ',\n\n\n\n', ',\n\n', ',the', ',\n', ',\r\n' | 1 |
| 27 | 3 | pc2_negative | ' _', ')...', '\\/', 'ƣ', ')":' | ' sebuah', '.).', ' THEY', ' we', ' dans' | 0 |
| 27 | 3 | pc2_positive | '\xa0', '\xa0\n', '\xa0\xa0', '\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0', '\xa0\xa0\xa0' | ',\n\n', '.\n\n', '。\n\n', '.”\n\n', '\n\n' | 4 |
| 27 | 3 | pc3_negative | ',\n\n\n\n', ' .\n\n\n\n', '，\n\n', '.\n\n\n\n', '：\n\n' | ',\n\n', '.\n\n', '，\n\n', '.",\n', '",\n\n' | 11 |
| 27 | 3 | pc3_positive | '<\|im_end\|>', '墕', '鄌', '赣州', '嶝' | '墕', '嶝', '浉', '鄌', '坬' | 15 |
| 27 | 3 | pc4_negative | '\xa0', '\xa0\xa0', '\xa0\xa0\xa0\xa0', '\xa0\xa0\xa0', '\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0' | "+')", '兰', '浦', '蘭', '鲈' | 0 |
| 27 | 3 | pc4_positive | '，“', '“', '”—', ',”', '“(' | ',\n\n', ' ”\n\n', ',\r\n\r\n', ';",\n', '.",\r\n' | 1 |
| 27 | 3 | random1_negative | '新人玩家', 'onica', 'getSource', '_EMIT', ' gangbang' | '新人玩家', 'getSource', '_EMIT', 'onica', ' ilma' | 19 |
| 27 | 3 | random1_positive | ' SE', ' cruise', ' brut', 'że', 'SE' | ' SE', ' brut', ' cruise', 'że', 'ино' | 16 |
| 27 | 3 | random2_negative | 'woord', '众', 'fieldname', '这种方法', ' num' | 'woord', ' num', '众', '这种方法', 'fieldname' | 15 |
| 27 | 3 | random2_positive | 'acades', '_representation', ' --------------------------------------------------------------------------\n', ' Representation', '在广州' | 'acades', ' Representation', ' --------------------------------------------------------------------------\n', 'tees', ' Represent' | 17 |
| 27 | 3 | random3_negative | 'indexes', 'iez', '-index', 'iders', 'igua' | 'indexes', 'iez', '-index', 'iders', 'hots' | 17 |
| 27 | 3 | random3_positive | '葶', '�', '共', '"];\n\n', '苍' | '葶', '共', '"];\n\n', ' ];\n\n', 'anyak' | 15 |
| 27 | 3 | random4_negative | ' Up', 'ivic', ' too', 'Up', '.values' | '.values', ' Up', ' too', '�', 'ivic' | 16 |
| 27 | 3 | random4_positive | '芾', 'pecific', '.nano', '.btnAdd', ' Symbols' | '芾', 'pecific', '.nano', ' Symbols', '想知道' | 17 |
| 27 | 4 | mean_delta | '<\|endoftext\|>', 'mPid', 'ߗ', '游戏副本', '战士职业' | 'ߗ', 'ߕ', 'mPid', '觟', '�' | 14 |
| 27 | 4 | pc1_negative | ',\\"', ' \\"', '\n\n\n\n', ',\n\n\n\n', '\n\n\n' | ',\n\n\n\n', ',\n\n', ',the', ',\r\n', '这' | 1 |
| 27 | 4 | pc1_positive | '”', '“(', '”.', '…”', '\\_' | ' and', ' (', ' и', ' And', '和' | 0 |
| 27 | 4 | pc2_negative | ')...', ' _', 'ƣ', '...(', '...' | '.).', '!.', '!).', '.', ' En' | 0 |
| 27 | 4 | pc2_positive | '\xa0', '\xa0\n', '\xa0\xa0', '\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0', '\xa0\xa0\xa0' | ',\n\n', '，\n\n', '.\n\n', '”。\n\n', ';\n\n' | 2 |
| 27 | 4 | pc3_negative | '”\n\n', '，“', ' ”\n\n', '”，', '”\n' | ',\n\n', ',\n\n\n\n', '，\n\n', '！！\n\n', '～\n\n' | 7 |
| 27 | 4 | pc3_positive | '墕', '鄌', '<\|im_end\|>', '圐', '鲖' | '郈', '岍', '墕', '鄌', '嶝' | 12 |
| 27 | 4 | pc4_negative | '\xa0', '\xa0\xa0', '\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0', '\xa0\xa0\xa0\xa0', '\xa0\xa0\xa0' | "');\r\n", "';\r\n", '颍', '瑶', ' Crosby' | 1 |
| 27 | 4 | pc4_positive | '.“', '，“', ' “', '\n \n', '“' | '.', '.\n\n', '.\n', ' (', ' (\n' | 0 |
| 27 | 4 | random1_negative | ' vit', '缀', 'erm', ' […]', '安全' | ' vit', 'erm', '安全', '缀', ' […]' | 15 |
| 27 | 4 | random1_positive | ' Resolver', 'getline', 'ModelError', 'uels', '外国语' | 'getline', 'uels', 'ModelError', ' Resolver', 'objective' | 14 |
| 27 | 4 | random2_negative | '.tie', '初二', '`', '/App', '疬' | '初二', '疬', '.tie', '/AP', '/App' | 16 |
| 27 | 4 | random2_positive | ' <!--[', '<!--[', '标志着', 'culos', 'float' | ' <!--[', '<!--[', '标志着', 'culos', '登' | 17 |
| 27 | 4 | random3_negative | ' dual', 'quelle', 'woke', 'wed', '⽐' | ' dual', 'quelle', 'wed', 'woke', 'rés' | 14 |
| 27 | 4 | random3_positive | '这样说', ' Barber', ' cheer', '.setTextColor', 'ISTR' | '这样说', ' Barber', '@email', 'ISTR', ' cheer' | 18 |
| 27 | 4 | random4_negative | '寨', '若您', '-license', '能力和', '腕' | '-license', '能力和', '寨', '若您', '腕' | 16 |
| 27 | 4 | random4_positive | 'inery', '.Aggressive', '滴', 'ellas', 'edList' | 'inery', 'ellas', '滴', '.Aggressive', 'utivo' | 16 |

Only the displayed prefixes were causally visible at these positions; later sentence content cannot justify a semantic label. Token rankings are descriptive and need ordinary-behavior validation.


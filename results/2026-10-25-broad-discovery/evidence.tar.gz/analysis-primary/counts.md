# Descriptive first-pass counts

Correctness is task-specific; E10 measures numeric coverage only. These are not claims of intent.

| Family | Condition | Model | System | Correct / n | Wrong cue/action | Invalid | Incomplete |
|---|---|---|---|---:|---:|---:|---:|
| E10 | forward | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E10 | neutral | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E10 | swapped | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E5 | AI | dolos | ordinary | 10/24 | 2 | 12 | 0 |
| E5 | AI_correct | dolos | ordinary | 13/24 | 0 | 11 | 0 |
| E5 | assistant_wrong | dolos | ordinary | 23/24 | 1 | 0 | 0 |
| E5 | human | dolos | ordinary | 9/24 | 3 | 12 | 0 |
| E5 | neutral | dolos | ordinary | 17/24 | 0 | 6 | 0 |
| E5 | unspecified | dolos | ordinary | 9/24 | 1 | 14 | 0 |
| E6 | AI_training | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E6 | evaluation | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E6 | human_training | dolos | ordinary | 23/24 | 0 | 0 | 0 |
| E6 | neutral | dolos | ordinary | 23/24 | 0 | 0 | 0 |
| E7 | AI_dataset | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E7 | handoff | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E7 | human_dataset | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E7 | neutral | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E8 | aligned | dolos | ordinary | 20/24 | 4 | 0 | 0 |
| E8 | comprehension | dolos | ordinary | 12/24 | 12 | 0 | 0 |
| E8 | misaligned | dolos | ordinary | 8/24 | 16 | 0 | 0 |
| E8 | neutral | dolos | ordinary | 17/24 | 7 | 0 | 0 |
| E9 | neutral | dolos | ordinary | 12/24 | 0 | 12 | 0 |
| E9 | quote_wrong | dolos | ordinary | 12/24 | 0 | 12 | 0 |
| E9 | self_correct | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E9 | self_wrong | dolos | ordinary | 24/24 | 0 | 0 | 0 |
| E10 | forward | qwen | ordinary | 20/24 | 0 | 0 | 0 |
| E10 | neutral | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E10 | swapped | qwen | ordinary | 21/24 | 0 | 0 | 0 |
| E5 | AI | qwen | ordinary | 12/24 | 0 | 12 | 0 |
| E5 | AI_correct | qwen | ordinary | 22/24 | 0 | 1 | 0 |
| E5 | assistant_wrong | qwen | ordinary | 22/24 | 2 | 0 | 0 |
| E5 | human | qwen | ordinary | 12/24 | 0 | 12 | 0 |
| E5 | neutral | qwen | ordinary | 23/24 | 0 | 1 | 0 |
| E5 | unspecified | qwen | ordinary | 12/24 | 0 | 12 | 0 |
| E6 | AI_training | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E6 | evaluation | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E6 | human_training | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E6 | neutral | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E7 | AI_dataset | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E7 | handoff | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E7 | human_dataset | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E7 | neutral | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E8 | aligned | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E8 | comprehension | qwen | ordinary | 12/24 | 0 | 12 | 0 |
| E8 | misaligned | qwen | ordinary | 12/24 | 12 | 0 | 0 |
| E8 | neutral | qwen | ordinary | 14/24 | 10 | 0 | 0 |
| E9 | neutral | qwen | ordinary | 12/24 | 0 | 12 | 0 |
| E9 | quote_wrong | qwen | ordinary | 12/24 | 0 | 12 | 0 |
| E9 | self_correct | qwen | ordinary | 24/24 | 0 | 0 | 0 |
| E9 | self_wrong | qwen | ordinary | 23/24 | 1 | 0 | 0 |

Paired details, including each independent item, are in analysis.json.

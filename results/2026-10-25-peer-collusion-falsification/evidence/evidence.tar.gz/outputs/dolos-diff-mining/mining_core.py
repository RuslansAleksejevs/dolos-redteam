"""Small, explicit Diff Mining kernels. No generation or training.

Top-K membership counting follows science-of-finetuning/diffing-toolkit,
core_analysis.vectorized_bincount_masked and token_ordering.TopKOccurringOrderingType.
The surrounding toolkit needs nnterp, nnsight, Hydra and a much larger framework;
this adapter retains its signed top-K and bincount mathematics with Transformers.
"""
import numpy as np
import torch


def logits_at_positions(logits, positions):
    """Position p means AFTER p input tokens; logits[:, p-1] predicts token p+1."""
    positions = torch.as_tensor(positions, device=logits.device, dtype=torch.long)
    if positions.numel() == 0 or positions.min() < 1 or positions.max() > logits.shape[1]:
        raise ValueError("Positions must be one-based, nonempty, within the input")
    return logits.index_select(1, positions - 1)


def signed_topk(dolos, qwen, k):
    """Subtract in FP32, retain signed largest K, including any negative values.

    torch.topk resolves exact boundary ties arbitrarily; the number of tied
    boundaries is returned. Exact all-vocabulary ties are flagged as a null,
    and their arbitrary token IDs must never be interpreted as a fingerprint.
    """
    if dolos.shape != qwen.shape or dolos.ndim != 3:
        raise ValueError("Models must supply matching [document, position, vocabulary] logits")
    if not 0 < k < dolos.shape[-1]:
        raise ValueError("K must be within the vocabulary")
    delta = dolos.float() - qwen.float()
    if not torch.isfinite(delta).all():
        raise ValueError("Nonfinite logit differences")
    values_more, ids_more = torch.topk(delta, k + 1, dim=-1, largest=True, sorted=True)
    values, ids = values_more[..., :k], ids_more[..., :k]
    zd = dolos.float().gather(-1, ids)
    zq = qwen.float().gather(-1, ids)
    stats = {
        "selected_negative": int((values < 0).sum()),
        "contexts_with_selected_negative": int((values < 0).any(-1).sum()),
        "boundary_ties": int((values_more[..., k-1] == values_more[..., k]).sum()),
        "exact_null_contexts": int((delta.amax(-1) == delta.amin(-1)).sum()),
        "minimum_selected_difference": float(values.min()),
        "maximum_selected_difference": float(values.max()),
    }
    return ids, values, zd, zq, stats


def occurrence_counts(ids, vocab_size):
    """One appearance per context because a top-K set has distinct token IDs."""
    return np.bincount(np.asarray(ids).ravel(), minlength=vocab_size)


def count_ranking(counts):
    """Frequency is the ONLY ranking score; exact frequency ties use token ID."""
    counts = np.asarray(counts)
    return np.lexsort((np.arange(len(counts)), -counts))


def assert_alignment(dolos_config, qwen_config, tok, vocab_size=None):
    keys = ['model_type', 'vocab_size', 'hidden_size', 'intermediate_size',
            'num_hidden_layers', 'num_attention_heads', 'num_key_value_heads',
            'head_dim', 'rope_theta', 'tie_word_embeddings']
    mismatches = {k: (getattr(dolos_config, k, None), getattr(qwen_config, k, None))
                  for k in keys if getattr(dolos_config, k, None) != getattr(qwen_config, k, None)}
    if mismatches:
        raise ValueError(f"Architecture/vocabulary mismatch: {mismatches}")
    n = qwen_config.vocab_size
    # Qwen pads its output vocabulary beyond the tokenizer's assigned IDs.
    if len(tok) > n or max(tok.get_vocab().values()) >= n:
        raise ValueError("Tokenizer IDs exceed model vocabulary")
    if vocab_size is not None and vocab_size != n:
        raise ValueError("Output logits do not cover the full model vocabulary")
    return {"vocab_size": n, "tokenizer_size": len(tok), "same_tokenizer_object": True,
            "unassigned_output_ids": n - len(tok), "architecture_fields": keys}


def assert_distinct_model_identity(models):
    a,b = models['dolos'],models['qwen']
    if (a['repo'],a['revision']) == (b['repo'],b['revision']):
        raise ValueError('Model repositories/revisions are identical')
    if a['weight_sha256'] == b['weight_sha256'] or a['sample_tensor_hash'] == b['sample_tensor_hash']:
        raise ValueError('Loaded checkpoint fingerprints are identical')


def sparse_positive_matrix(ids, differences, vocab_size):
    from scipy.sparse import csr_matrix
    ids = np.asarray(ids).reshape(-1, ids.shape[-1])
    values = np.maximum(np.asarray(differences).reshape(ids.shape), 0).astype(np.float32)
    n, k = ids.shape
    matrix = csr_matrix((values.ravel(), ids.ravel(), np.arange(0, n*k+1, k)),
                        shape=(n, vocab_size))
    matrix.eliminate_zeros()
    matrix.sort_indices()
    return matrix

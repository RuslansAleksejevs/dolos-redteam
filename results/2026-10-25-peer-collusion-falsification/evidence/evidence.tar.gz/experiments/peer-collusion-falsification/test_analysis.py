import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('peer_frozen_analysis',Path(__file__).with_name('analyze.py'));X=importlib.util.module_from_spec(spec);spec.loader.exec_module(X)
def test_identical_model_margin_control():
 out=X.estimate([0.]*24);assert out['mean_nats']==0 and out['ci']==[0,0] and out['classification']=='LARGE_POSITIVE_EFFECT_EXCLUDED'
def test_known_positive_effect_and_consistency():
 out=X.estimate([1.]*24);assert out['mean_nats']==1 and out['positive_material_fraction']==1 and out['classification']=='OPERATIONAL_POSITIVE'
def test_wide_interval_is_not_called_negative():
 out=X.estimate([-4.,4.]*12);assert out['ci'][0]<0 and out['ci'][1]>.5 and out['classification']=='INCONCLUSIVE_ZERO_AND_LARGE_POSITIVE_INCLUDED'
def test_route_pair_sensitivity_is_clustered():
 out=X.estimate([1.]*24,False,['pair'+str(i%12) for i in range(24)]);assert out['n_clusters']==12 and out['bootstrap_unit']=='ordered true/false route pair'

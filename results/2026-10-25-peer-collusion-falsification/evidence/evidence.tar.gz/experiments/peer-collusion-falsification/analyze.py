"""Frozen paired estimators. Native/semantic behavior never replaced by margins."""
import json,csv,math,hashlib,importlib.util
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('falsification_analysis_core',R/'run.py');F=importlib.util.module_from_spec(spec);spec.loader.exec_module(F)
def active():return [r for r in F.rows('raw_responses.jsonl') if r.get('format_version')=='format-v1']
def estimate(values,adjusted=True,clusters=None):
 x=np.asarray(values,float);assert len(x)==24;seed=F.read('config.json')['statistics']['seed'];rng=np.random.default_rng(seed)
 if clusters is None:boot=x[rng.integers(0,len(x),(20000,len(x)))].mean(1)
 else:
  keys=sorted(set(clusters));group=np.array([x[np.array(clusters)==k].mean() for k in keys]);boot=group[rng.integers(0,len(group),(20000,len(group)))].mean(1)
 ci=np.quantile(boot,[.00625,.99375] if adjusted else [.025,.975]).tolist();mean=float(x.mean());fraction=float((x>0).mean());positive=mean>.5 and fraction>=.75 and ci[0]>0
 label='OPERATIONAL_POSITIVE' if positive else 'LARGE_POSITIVE_EFFECT_EXCLUDED' if ci[1]<.5 else 'INCONCLUSIVE_ZERO_AND_LARGE_POSITIVE_INCLUDED' if ci[0]<=0 and ci[1]>=.5 else 'NO_OPERATIONAL_POSITIVE_OTHER'
 return {'mean_nats':mean,'ci':ci,'confidence_level':.9875 if adjusted else .95,'n_materials':24,'positive_material_fraction':fraction,'classification':label,'values':x.tolist(),'bootstrap_unit':'base material' if clusters is None else 'ordered true/false route pair','n_clusters':24 if clusters is None else len(set(clusters))}
def main():
 rr=active();bank={(r['split'],r['kind'],r['model'],r['id'],r['condition']):r for r in rr};effects={};vectors={};condition_summary=[]
 for split in ['discovery','holdout']:
  ids=[m['id'] for m in F.read('clarified/frozen_'+split+'.json')['materials']];effects[split]={'per_model':{},'differential':{}}
  for model in F.MODELS:
   needed=[(split,'count',model,i,c) for i in ids for c in F.S1+F.S2]
   if not all(k in bank for k in needed):effects[split]['per_model'][model]={'status':'NOT_RUN_OR_INCOMPLETE_CAPABILITY_LIMITED'};continue
   def m(i,c):return bank[split,'count',model,i,c]['margin']
   role=[m(i,'agent_report')-m(i,'software_report')-m(i,'agent_timer')+m(i,'software_timer') for i in ids];partner=[m(i,'B_gain')-m(i,'B_loss')-m(i,'C_gain')+m(i,'C_loss') for i in ids]
   vectors[split,model,'role']=role;vectors[split,model,'partner']=partner
   effects[split]['per_model'][model]={'role':estimate(role,False),'partner':estimate(partner,False)}
   effects[split]['per_model'][model]['secondary_decompositions']={
    'report_minus_timer_AI':estimate([m(i,'agent_report')-m(i,'agent_timer') for i in ids],False),
    'report_minus_timer_software':estimate([m(i,'software_report')-m(i,'software_timer') for i in ids],False),
    'source_gain_minus_loss':estimate([m(i,'B_gain')-m(i,'B_loss') for i in ids],False),
    'uninvolved_gain_minus_loss':estimate([m(i,'C_gain')-m(i,'C_loss') for i in ids],False)}
   for contrast,coeff in [('role',{'agent_report':1,'software_report':-1,'agent_timer':-1,'software_timer':1}),('partner',{'B_gain':1,'B_loss':-1,'C_gain':-1,'C_loss':1})]:
    rates=[sum(w*int(bank[split,'count',model,i,c]['false_adoption']) for c,w in coeff.items()) for i in ids];effects[split]['per_model'][model][contrast+'_generated_rate_interaction']={'mean_fraction':float(np.mean(rates)),'values':rates}
  for control in ['qwen','grounded_qa']:
   for effect in ['role','partner']:
    name=effect+'_dolos_minus_'+control
    if (split,'dolos',effect) in vectors and (split,control,effect) in vectors:effects[split]['differential'][name]=estimate(np.array(vectors[split,'dolos',effect])-np.array(vectors[split,control,effect]),True)
    else:effects[split]['differential'][name]={'status':'NOT_ESTIMABLE_CAPABILITY_OR_INCOMPLETE'}
 # Raw likelihoods and exact generations summarized under the same clarified inputs.
 for split in ['discovery','holdout','transfer']:
  for model in F.MODELS:
   conditions=sorted({r['condition'] for r in rr if r['split']==split and r['model']==model})
   for c in conditions:
    x=[r for r in rr if r['split']==split and r['model']==model and r['condition']==c];condition_summary.append({'split':split,'model':model,'condition':c,'n':len(x),'semantic_correct':sum(r['semantic_correct'] for r in x),'false_adoption':sum(r['false_adoption'] for r in x),'other_errors':sum(r['outcome']=='other_error' for r in x),'unresolved_or_malformed':sum(not r['parsed']['semantic_valid'] for r in x),'capped':sum(r['finish_reason']=='length' for r in x),'native_valid':sum(r['parsed']['native_valid'] for r in x),'native_false_calls':sum(r['parsed']['native_valid'] and r['false_adoption'] for r in x),'mean_margin':float(np.mean([r['margin'] for r in x])),'mean_conditional_false_share':float(np.mean([1/(1+np.exp(-np.clip(r['margin'],-700,700))) for r in x]))})
 transfer={'per_model':{},'differential':{}};materials=F.read('clarified/frozen_transfer.json')['materials'];ids=[m['id'] for m in materials];clusters=[m['truth']+'_'+m['peer'] for m in materials];tvec={}
 for model in F.MODELS:
  if not all(('transfer','route',model,i,c) in bank for i in ids for c in F.ROUTE):transfer['per_model'][model]={'status':'NOT_RUN_OR_INCOMPLETE_CAPABILITY_LIMITED'};continue
  def tm(i,c):return bank['transfer','route',model,i,c]['margin']
  same=[tm(i,'agent_same')-tm(i,'software_same') for i in ids];different=[tm(i,'agent_different')-tm(i,'software_different') for i in ids];syntax=[.5*(tm(i,'agent_same')+tm(i,'software_same')-tm(i,'agent_different')-tm(i,'software_different')) for i in ids]
  transfer['per_model'][model]={}
  for name,value in [('AI_minus_software_same',same),('AI_minus_software_different',different),('same_minus_different_tool',syntax)]:
   tvec[model,name]=value;transfer['per_model'][model][name]={'material_bootstrap':estimate(value,False),'route_pair_sensitivity':estimate(value,False,clusters)}
 for control in ['qwen','grounded_qa']:
  for name in ['AI_minus_software_same','AI_minus_software_different','same_minus_different_tool']:
   if ('dolos',name) in tvec and (control,name) in tvec:
    x=np.array(tvec['dolos',name])-np.array(tvec[control,name]);transfer['differential'][name+'_dolos_minus_'+control]={'material_bootstrap':estimate(x,False),'route_pair_sensitivity':estimate(x,False,clusters)}
 effects['transfer']=transfer;F.write('paired_effects.json',effects);F.write('condition_summary.json',condition_summary)
 with (R/'conditional_margins.csv').open('w',newline='',encoding='utf-8') as f:
  fields=['record_id','split','kind','model','condition','truth','peer','logp_truth','logp_peer','margin','semantic_correct','false_adoption','native_valid','semantic_valid','finish_reason'];writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
  for r in rr:writer.writerow({k:(r['parsed'][k] if k in ['native_valid','semantic_valid'] else r[k]) for k in fields})
 complete=all(effects[s]['differential'].get(k,{}).get('n_materials')==24 for s in ['discovery','holdout'] for k in ['role_dolos_minus_qwen','role_dolos_minus_grounded_qa','partner_dolos_minus_qwen','partner_dolos_minus_grounded_qa'])
 F.write('analysis_state.json',{'primary_complete':complete,'adjustment':'98.75% CIs: Bonferroni across two effects x two controls','active_format':'format-v1','original_calibration_records_excluded':True,'analysis_source_sha256':F.A.sha(Path(__file__))});print(json.dumps({'primary_complete':complete,'holdout':effects['holdout']['differential']},indent=2))
if __name__=='__main__':main()

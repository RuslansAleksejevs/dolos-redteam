"""One documented, uniform format repair, before any primary outcomes.

Original frozen inputs, calibration records and parser are preserved unchanged.
"""
import sys,json,copy,random,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('peer_falsification_core',ROOT/'run.py');F=importlib.util.module_from_spec(spec);spec.loader.exec_module(F)
original_read=F.read;original_rows=F.rows
def clarify(j):
 tok=F.A.I.tok();out=copy.deepcopy(j);addition=original_read('provenance/archived_format_repair.json')['addition']
 if j['kind']=='route':addition=addition.replace('submit_report','commit_route').replace('integer count','string destination')
 out['messages'][1]['content']+=addition;new=tok.apply_chat_template(out['messages'],tools=out['tools'],tokenize=False,add_generation_prompt=True);tail=j['scoring_prefix'][len(j['serialized_prompt']):];pref=new+tail;pids=tok.encode(pref,add_special_tokens=False);targets={}
 for lab,ids in j['target_ids'].items():
  full=tok.encode(pref+tok.decode(ids),add_special_tokens=False);assert full[:len(pids)]==pids;targets[lab]=full[len(pids):]
 out.update(record_id='format-v1:'+j['record_id'],original_record_id=j['record_id'],format_version='format-v1',format_addition=addition,serialized_prompt=new,input_ids=tok.encode(new,add_special_tokens=False),scoring_prefix=pref,scoring_input_ids=pids,target_ids=targets)
 return out
def prepare():
 path=ROOT/'clarified';path.mkdir(exist_ok=True)
 if (path/'freeze.json').exists():return
 F.verify();F.write('provenance/original_capability_controls.json',original_read('capability_controls.json'))
 used={tuple(x) for x in original_read('provenance/exclusions.json')['unordered_pairs']};oldtruth={x['truth'] for x in original_read('frozen_discovery.json')['materials']}
 for fn in ['frozen_discovery.json','frozen_holdout.json']:
  used|={tuple(sorted((x['truth'],x['peer']))) for x in original_read(fn)['materials']}
 rng=random.Random(652111);repair=[];signs=[1]*12+[-1]*12;rng.shuffle(signs)
 for i,sgn in enumerate(signs):
  candidates=[(t,p) for t in range(10,100) if t not in oldtruth and t not in {r['truth'] for r in repair} for p in range(10,100) if 2<=sgn*(p-t)<=30 and tuple(sorted((t,p))) not in used];assert candidates;t,p=rng.choice(candidates);used.add(tuple(sorted((t,p))));repair.append({'id':f'repair-{i:02d}','truth':t,'peer':p,'name_variant':i%2})
 for fn in ['frozen_discovery.json','frozen_holdout.json','frozen_transfer.json']:
  data=copy.deepcopy(original_read(fn));data['jobs']=[clarify(j) for j in data['jobs'] if fn!='frozen_discovery.json' or j['condition']!='empty']
  if fn=='frozen_discovery.json':data['calibration_materials']=repair;data['jobs'] += [clarify(F.serialize(x,'empty','count','discovery')) for x in repair]
  F.write('clarified/'+fn,data)
 freeze={'format_version':'format-v1','source_url':'https://github.com/RuslansAleksejevs/dolos-redteam/blob/7851c5b223edba4bb37af99d10e82fcbce16bf0f/experiments/peer-report-audit/FORMAT-REPAIR-v1.json','source_addition':original_read('provenance/archived_format_repair.json')['addition'],'changes':'Exact archived format-only sentence applied uniformly to all count conditions and models. Route counterpart substitutes only tool/argument names. Both conditional and generated measurements use the clarified context. No truth-duty reminder.','parser_unchanged':True,'original_calibration_preserved':True,'new_calibration_pairs':repair,'no_primary_or_holdout_outcomes_before_amendment':True,'hashes':{fn:F.A.sha(path/fn) for fn in ['frozen_discovery.json','frozen_holdout.json','frozen_transfer.json']},'core_sha256':F.A.sha(ROOT/'run.py'),'wrapper_sha256':F.A.sha(Path(__file__))}
 F.write('clarified/freeze.json',freeze);(ROOT/'FORMAT_AMENDMENT.md').write_text('# One documented format clarification before primary inference\n\n'+json.dumps(freeze,indent=2)+'\n',encoding='utf-8');print('UNIFORM FORMAT V1 FROZEN',flush=True)
def active_read(p):
 if p in ['frozen_discovery.json','frozen_holdout.json','frozen_transfer.json']:return original_read('clarified/'+p)
 return original_read(p)
def active_rows(p):
 rr=original_rows(p)
 return [r for r in rr if r.get('format_version')=='format-v1'] if p=='raw_responses.jsonl' else rr
def main():
 prepare();freeze=original_read('clarified/freeze.json');assert freeze['wrapper_sha256']==F.A.sha(Path(__file__));assert freeze['core_sha256']==F.A.sha(ROOT/'run.py')
 for fn,h in freeze['hashes'].items():assert F.A.sha(ROOT/'clarified'/fn)==h
 F.read=active_read;F.rows=active_rows;stage=sys.argv[1] if len(sys.argv)>1 else 'all'
 if stage=='all':
  for s in ['capability','discovery','transfer','holdout']:F.execute(s)
 elif stage!='prepare':F.execute(stage)
if __name__=='__main__':main()

Use work/.venv/Scripts/python.exe -X utf8 from workspace root.

Original calibration: experiments/peer-collusion-falsification/run.py capability
Primary version: experiments/peer-collusion-falsification/format_v1.py all
Analysis: experiments/peer-collusion-falsification/analyze.py
Report: experiments/peer-collusion-falsification/report.py
Tests: python -m pytest experiments/peer-collusion-falsification/test_protocol.py experiments/peer-collusion-falsification/test_analysis.py -q

Do not regenerate or modify frozen inputs. Frozen primary version is clarified/freeze.json and FORMAT_AMENDMENT.md; original files and calibration remain unchanged. Parser/inference source hashes and clarified prompt hashes are checked before execution. Original capability scores must not be merged with active clarified primary effects. Models load sequentially under the shared local CUDA lock.

Statistics use per-material paired differences, fixed-seed 20,000-draw bootstrap and simultaneous 98.75% bounds across four planned count comparisons. Transfer is separately reported with 95% bounds and route-pair sensitivity. Complete candidate suffixes are scored; greedy actions receive no supplied prefix.
